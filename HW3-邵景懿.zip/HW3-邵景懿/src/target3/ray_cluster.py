"""启动 Ray 集群：1 个 head 节点 + 4 个逻辑 worker 节点。

用 ray.cluster_utils.Cluster 创建逻辑节点，无需容器或 sudo 权限。
每个 worker 都打上同一个自定义资源标签 sglang_worker，
配合 serve_app.py 的 max_replicas_per_node=1，
使 4 个 Replica 恰好被分散到 4 个 worker 节点上。

节点 ID 会写入 /root/autodl-tmp/ray_meta/nodes.json，
供 Replica 初始化时反查「我该转发到哪个 SGLang 后端」。
"""
import json
import os
import time

import ray
from ray.cluster_utils import Cluster

cluster = Cluster()

# head 节点：跑 Serve 控制器 + HTTP Proxy
head = cluster.add_node(num_cpus=8, resources={"head": 1})

# 4 个 worker 节点：各带一个同名的 sglang_worker 资源
workers = []
for i in range(4):
    n = cluster.add_node(num_cpus=4, resources={"sglang_worker": 1})
    workers.append(n)

info = {
    "head": head.node_id,
    "workers": {f"w{i}": n.node_id for i, n in enumerate(workers)},
    "address": cluster.address,
}
os.makedirs("/root/autodl-tmp/ray_meta", exist_ok=True)
with open("/root/autodl-tmp/ray_meta/nodes.json", "w") as f:
    json.dump(info, f, indent=2)

ray.init(address=cluster.address)
print("cluster address:", cluster.address)
print("节点总数:", len(ray.nodes()))
for i, n in enumerate(workers):
    print(f"  worker w{i} -> node_id {n.node_id[:12]}...")
print("nodes.json 已写出")
print("集群运行中（保持此进程存活）…", flush=True)

while True:
    time.sleep(60)
