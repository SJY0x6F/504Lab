"""D 组自定义路由器：前缀亲和 + 队列深度兜底。

设计思路
  1. 复用 ConsistentHashRouter 的一致性哈希环，用 X-Session-Id 定位「亲和副本」；
  2. 并发查询所有候选副本当前的排队深度；
  3. 只有当亲和副本的队列明显长于全场最闲副本时
     （q_affinity > overflow_ratio * q_min + overflow_slack），
     才改投最闲副本：用少量缓存复用换取不过载；
  4. 返回完整的候选链，使被主副本拒绝的请求能立即溢出到下一级
     （靠 num_fallback_replicas=3 让父类在环上收集全部 4 个副本）。

路由器只使用当前请求与当前服务状态，不读取未来请求。
"""
import asyncio
import logging
from typing import Dict, List, Optional

from ray.serve._private.constants import SERVE_LOGGER_NAME
from ray.serve._private.request_router.common import PendingRequest
from ray.serve._private.request_router.replica_wrapper import RunningReplica
from ray.serve.experimental.consistent_hash_router import ConsistentHashRouter

logger = logging.getLogger(SERVE_LOGGER_NAME)


class AffinityAwareRouter(ConsistentHashRouter):
    """在「纯前缀亲和」(C) 与「纯负载均衡」(A/B) 之间做可调权衡。"""

    def initialize_state(self, **kwargs) -> None:
        super().initialize_state(**kwargs)
        self._overflow_ratio = float(kwargs.get("overflow_ratio", 1.5))
        self._overflow_slack = int(kwargs.get("overflow_slack", 2))
        self._overflow_count = 0
        self._route_count = 0
        logger.info(
            "AffinityAwareRouter initialized: overflow_ratio=%s overflow_slack=%s",
            self._overflow_ratio,
            self._overflow_slack,
        )

    async def _queue_lens(self, replicas: List[RunningReplica]) -> Dict[object, Optional[int]]:
        """并发问每个副本「现在排了多少个请求」，失败记为 None。"""
        deadline = getattr(self, "queue_len_response_deadline_s", 0.05)

        async def one(r: RunningReplica):
            try:
                return r.replica_id, int(await r.get_queue_len(deadline_s=deadline))
            except Exception:
                return r.replica_id, None

        return dict(await asyncio.gather(*[one(r) for r in replicas]))

    async def choose_replicas(
        self,
        candidate_replicas: List[RunningReplica],
        pending_request: Optional[PendingRequest] = None,
    ) -> List[List[RunningReplica]]:
        if not candidate_replicas:
            return []

        if pending_request is not None:
            pending_request.routing_context.should_backoff = True

        routing_key = self._routing_key(pending_request)
        if routing_key is None:
            return [candidate_replicas]

        # ① 环上取亲和序（num_fallback_replicas=3 时能拿到全部 4 个）
        ranked: List[RunningReplica] = []
        for rid in self._lookup_ranked_replicas(routing_key):
            r = self._replicas.get(rid)
            if r is not None:
                ranked.append(r)
        seen = {r.replica_id for r in ranked}
        ranked += [r for r in candidate_replicas if r.replica_id not in seen]
        if not ranked:
            return [candidate_replicas]

        affinity = ranked[0]
        chosen = affinity
        self._route_count += 1

        # ② 队列深度兜底
        if len(ranked) > 1:
            queues = await self._queue_lens(ranked)
            known = {k: v for k, v in queues.items() if v is not None}
            q_aff = queues.get(affinity.replica_id)
            if q_aff is not None and known:
                q_min = min(known.values())
                if q_aff > self._overflow_ratio * q_min + self._overflow_slack:
                    alt_id = min(known, key=lambda k: known[k])
                    alt = self._replicas.get(alt_id)
                    if alt is not None and alt.replica_id != affinity.replica_id:
                        chosen = alt
                        self._overflow_count += 1

        if self._route_count % 200 == 0:
            logger.info(
                "AffinityAwareRouter: %d routes, %d overflowed (%.1f%%)",
                self._route_count,
                self._overflow_count,
                100.0 * self._overflow_count / max(self._route_count, 1),
            )

        rest = [r for r in ranked if r.replica_id != chosen.replica_id]
        return [[chosen]] + [[r] for r in rest]
