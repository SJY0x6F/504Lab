# -*- coding: utf-8 -*-
"""从各组 requests.csv 导出 TTFT / 端到端延迟的百分位（供绘制 CDF 图）。

用法：按实际结果目录修改 RUNS 后执行，输出 CSV 风格表格。
"""
import csv

RUNS = [("A",  "/root/autodl-tmp/hw3_results/A_default/requests.csv"),
        ("B1", "/root/autodl-tmp/hw3_results/B_p2c_32/requests.csv"),
        ("B2", "/root/autodl-tmp/hw3_results/B_p2c_64/requests.csv"),
        ("C",  "/root/autodl-tmp/hw3_results/C_affinity/requests.csv"),
        ("D",  "/root/autodl-tmp/hw3_results/D_affinity_aware/requests.csv")]
PS = list(range(1, 100, 5)) + [99, 99.5]


def load(path, col):
    out = []
    with open(path, newline="") as f:
        for row in csv.DictReader(f):
            try:
                out.append(float(row[col]))
            except Exception:
                pass
    return sorted(out)


def q(v, p):
    i = int(round((p / 100.0) * (len(v) - 1)))
    return v[min(max(i, 0), len(v) - 1)]


for col in ("ttft_s", "latency_s"):
    print("### " + col + " 百分位(毫秒)")
    data = {n: load(p, col) for n, p in RUNS}
    print("p," + ",".join(n for n, _ in RUNS))
    for p in PS:
        print(str(p) + "," + ",".join("%.2f" % (q(data[n], p) * 1000) for n, _ in RUNS))
    print("")
