#!/usr/bin/env python3
"""HW3 目标三：Ray Serve 四副本路由（可切换路由器配置）。

四个 Replica 通过自定义资源 sglang_worker + max_replicas_per_node=1
被强制分散到 4 个 worker 节点上，并按节点身份固定转发到一个 SGLang 后端。

用法：
  PYTHONPATH=/root/autodl-tmp python serve_app.py --router p2c --max-ongoing-requests 64
"""
import argparse
import json

import aiohttp
import ray
from ray import serve
from ray.serve.config import RequestRouterConfig
from starlette.requests import Request
from starlette.responses import JSONResponse, Response, StreamingResponse

NODES_JSON = "/root/autodl-tmp/ray_meta/nodes.json"
BASE_PORT = 30000
FWD = ("x-session-id", "x-workload-request-id", "x-prefix-family", "content-type")


def load_node_map():
    with open(NODES_JSON) as f:
        info = json.load(f)
    return {info["workers"][f"w{i}"]: i for i in range(4)}


@serve.deployment
class Router:
    def __init__(self):
        self.node_map = load_node_map()
        self._session = None

    def _resolve(self):
        ctx = ray.get_runtime_context()
        node_id = ctx.get_node_id()
        idx = self.node_map[node_id]
        return idx, node_id, f"http://127.0.0.1:{BASE_PORT + idx}", ctx.get_actor_id()

    async def _sess(self):
        if self._session is None:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=300))
        return self._session

    async def __call__(self, request: Request) -> Response:
        path = request.url.path
        idx, node_id, backend, replica_id = self._resolve()

        if path == "/replica_info":
            return JSONResponse({
                "replica_id": replica_id,
                "node_id": node_id,
                "backend": idx,
                "backend_url": backend,
            })

        if path == "/generate" and request.method == "POST":
            body = await request.body()
            headers = {}
            for h in FWD:
                v = request.headers.get(h)
                if v is not None:
                    headers[h] = v

            sess = await self._sess()
            up = await sess.post(f"{backend}/generate", data=body, headers=headers)

            async def relay():
                try:
                    async for chunk in up.content.iter_any():
                        yield chunk
                finally:
                    up.release()

            return StreamingResponse(
                relay(),
                status_code=up.status,
                media_type=up.headers.get("Content-Type", "text/event-stream"),
                headers={
                    "X-Ray-Replica-ID": replica_id,
                    "X-Ray-Node-ID": node_id,
                    "X-SGLang-Backend": f"backend-{idx}",
                },
            )

        return Response("not found", status_code=404)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--router", choices=["p2c", "consistent_hash", "d_custom"], default="p2c")
    ap.add_argument("--max-ongoing-requests", type=int, default=5)
    ap.add_argument("--num-fallback-replicas", type=int, default=0)
    ap.add_argument("--num-virtual-nodes", type=int, default=100)
    ap.add_argument("--overflow-ratio", type=float, default=1.5)
    ap.add_argument("--overflow-slack", type=int, default=2)
    args = ap.parse_args()

    opts = {
        "num_replicas": 4,
        "max_ongoing_requests": args.max_ongoing_requests,
        "max_replicas_per_node": 1,
        "ray_actor_options": {"resources": {"sglang_worker": 0.001}},
    }
    if args.router == "d_custom":
        opts["request_router_config"] = RequestRouterConfig(
            request_router_class="affinity_router.AffinityAwareRouter",
            request_router_kwargs={
                "num_virtual_nodes": args.num_virtual_nodes,
                "num_fallback_replicas": 3,
                "overflow_ratio": args.overflow_ratio,
                "overflow_slack": args.overflow_slack,
            },
        )
    elif args.router == "consistent_hash":
        opts["request_router_config"] = RequestRouterConfig(
            request_router_class=(
                "ray.serve.experimental.consistent_hash_router.ConsistentHashRouter"),
            request_router_kwargs={
                "num_virtual_nodes": args.num_virtual_nodes,
                "num_fallback_replicas": args.num_fallback_replicas,
            },
        )

    ray.init(address="auto", namespace="hw3", logging_level="ERROR")
    serve.run(Router.options(**opts).bind(), name="router", route_prefix="/")
    print(f"部署完成: router={args.router} max_ongoing_requests={args.max_ongoing_requests}")


main()
