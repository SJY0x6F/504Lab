# -*- coding: utf-8 -*-
"""打印 Ray 集群各节点的资源占用（确认 4 个 worker 都带 sglang_worker 标签）。

用法：python show_nodes.py
"""
import ray

ray.init(address="auto", logging_level="ERROR")
count = 0
for n in ray.nodes():
    res = {k: v for k, v in n["Resources"].items() if not k.startswith("node:")}
    if res.get("sglang_worker"):
        count += 1
    print(n["NodeID"][:12], "alive=", n["Alive"], res)
print(f"带 sglang_worker 标签的节点数：{count}（应为 4）")
