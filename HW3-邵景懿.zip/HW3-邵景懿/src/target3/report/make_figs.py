# -*- coding: utf-8 -*-
"""生成 HW3 报告用的矢量图（SVG，无外部依赖）。"""
import math
import os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(OUT, exist_ok=True)

RUNS = ["A", "B1", "B2", "C", "D"]
LEGEND = {
    "A": "A  p2c, max_ongoing=5",
    "B1": "B1  p2c, max_ongoing=32",
    "B2": "B2  p2c, max_ongoing=64",
    "C": "C  consistent_hash, fallback=0",
    "D": "D  AffinityAwareRouter（自定义）",
}
COLOR = {"A": "#9AA5B1", "B1": "#6BAED6", "B2": "#2171B5", "C": "#E6550D", "D": "#238B45"}

PS = [1, 6, 11, 16, 21, 26, 31, 36, 41, 46, 51, 56, 61, 66, 71, 76, 81, 86, 91, 96, 99, 99.5]

TTFT = {
    "A":  [22.00, 25.14, 29.02, 34.50, 69.90, 317.41, 1779.62, 3086.01, 4548.32, 5856.72,
           7494.67, 8513.43, 9881.33, 11249.98, 12309.21, 12988.12, 14114.14, 14927.43,
           15889.04, 16923.50, 17871.96, 17950.37],
    "B1": [21.19, 23.31, 24.96, 27.59, 31.34, 34.70, 45.14, 703.65, 1478.67, 2284.41,
           2915.94, 3672.08, 4543.03, 5152.62, 5637.49, 5948.98, 6385.29, 6664.42,
           6989.88, 7454.99, 7902.31, 7987.37],
    "B2": [21.78, 23.89, 25.32, 27.44, 31.16, 34.88, 39.45, 43.25, 47.63, 53.05,
           63.10, 143.28, 294.47, 388.72, 507.73, 670.85, 884.24, 1051.98,
           1256.32, 1731.67, 1921.50, 1977.19],
    "C":  [22.06, 24.21, 26.14, 28.93, 34.54, 41.35, 50.01, 76.89, 122.32, 166.90,
           236.34, 426.32, 918.05, 3106.34, 6013.78, 8561.78, 11081.28, 14520.14,
           17084.27, 19666.14, 23094.62, 24750.55],
    "D":  [23.02, 24.81, 25.96, 27.00, 29.02, 32.06, 35.62, 40.01, 44.21, 48.51,
           55.64, 65.39, 89.77, 149.38, 226.22, 324.07, 441.18, 631.30,
           972.29, 1432.80, 2349.49, 2713.98],
}

LAT = {
    "A":  [115.21, 288.33, 433.33, 539.96, 593.29, 767.66, 2174.19, 3438.14, 4976.14, 6219.82,
           7898.39, 8904.95, 10211.65, 11656.26, 12691.70, 13434.01, 14451.58, 15316.96,
           16269.25, 17236.43, 18247.00, 18423.64],
    "B1": [109.14, 269.41, 409.48, 530.18, 587.77, 731.93, 1879.17, 2705.15, 3384.48, 4112.42,
           4867.65, 5696.35, 6280.63, 6821.47, 7358.00, 7790.62, 8187.74, 8574.68,
           9128.26, 9758.07, 10593.69, 10802.59],
    "B2": [108.33, 257.69, 386.65, 507.67, 567.18, 625.41, 891.66, 1270.70, 1546.31, 1860.42,
           2157.91, 2409.31, 2738.54, 3029.71, 3344.79, 3611.70, 3896.47, 4088.77,
           4308.47, 4835.44, 5424.01, 5519.46],
    "C":  [100.43, 191.41, 259.24, 330.95, 386.69, 447.07, 511.43, 597.87, 697.69, 901.07,
           2288.01, 3052.29, 3390.80, 5460.14, 8171.73, 10729.28, 13461.45, 16379.34,
           19447.07, 22024.75, 25531.35, 27058.80],
    "D":  [99.13, 222.89, 320.01, 413.01, 507.08, 555.79, 603.58, 718.79, 969.99, 1325.08,
           1624.43, 1918.57, 2206.10, 2481.09, 2734.94, 3092.03, 3363.81, 3565.34,
           3839.69, 4178.93, 5067.98, 5392.61],
}

DIST = {
    "A":  [517, 504, 522, 505],
    "B1": [481, 531, 517, 519],
    "B2": [496, 510, 540, 502],
    "C":  [217, 1150, 378, 303],
    "D":  [497, 555, 513, 483],
}


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def cdf_figure():
    W = 930
    x0, x1 = 86, 648
    lo, hi = math.log10(10.0), math.log10(40000.0)
    ph = 228
    top1, top2 = 100, 394
    H = top2 + ph + 74

    def X(p):
        return x0 + (p / 100.0) * (x1 - x0)

    def Y(v, top):
        lv = math.log10(max(v, 1.0))
        f = (lv - lo) / (hi - lo)
        return top + ph * (1.0 - f)

    s = []
    s.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
             f'viewBox="0 0 {W} {H}" font-family="Microsoft YaHei, Segoe UI, sans-serif">')
    s.append(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')

    s.append('<text x="86" y="34" font-size="17" font-weight="600" fill="#12395e">'
             '图 1&#160;&#160;五种路由配置的 TTFT 与端到端延迟累积分布（CDF）</text>')
    s.append('<text x="86" y="56" font-size="11.5" fill="#666">'
             '横轴=请求百分位，纵轴=耗时（对数刻度，ms）；曲线越靠左下越好</text>')

    panels = [("TTFT（首 token 延迟）", TTFT, top1), ("端到端延迟", LAT, top2)]

    yticks = [10, 30, 100, 300, 1000, 3000, 10000, 30000]

    for title, data, top in panels:
        s.append(f'<text x="86" y="{top - 12}" font-size="12.5" font-weight="600" '
                 f'fill="#12395e">{esc(title)}</text>')
        for t in yticks:
            y = Y(t, top)
            if y < top - 1 or y > top + ph + 1:
                continue
            s.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x1}" y2="{y:.1f}" '
                     f'stroke="#E6EAEE" stroke-width="1"/>')
            s.append(f'<text x="{x0 - 8}" y="{y + 3.5:.1f}" font-size="10.5" fill="#8894A0" '
                     f'text-anchor="end">{t}</text>')
        s.append(f'<line x1="{x0}" y1="{top + ph}" x2="{x1}" y2="{top + ph}" '
                 f'stroke="#B9C2CC" stroke-width="1"/>')
        s.append(f'<line x1="{x0}" y1="{top}" x2="{x0}" y2="{top + ph}" '
                 f'stroke="#B9C2CC" stroke-width="1"/>')
        for p in (0, 25, 50, 75, 95, 100):
            x = X(p)
            s.append(f'<line x1="{x:.1f}" y1="{top + ph}" x2="{x:.1f}" y2="{top + ph + 4}" '
                     f'stroke="#B9C2CC" stroke-width="1"/>')
            s.append(f'<text x="{x:.1f}" y="{top + ph + 17}" font-size="10.5" fill="#8894A0" '
                     f'text-anchor="middle">{p}</text>')
        # 50 / 95 参考线
        for p, col in ((50, "#C9A227"), (95, "#C0392B")):
            x = X(p)
            s.append(f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + ph}" '
                     f'stroke="{col}" stroke-width="1" stroke-dasharray="4,3" opacity="0.65"/>')

        for name in RUNS:
            pts = " ".join(f"{X(PS[i]):.1f},{Y(data[name][i], top):.1f}" for i in range(len(PS)))
            lw = 2.6 if name in ("C", "D") else 1.7
            op = 1.0 if name in ("C", "D") else 0.85
            s.append(f'<polyline points="{pts}" fill="none" stroke="{COLOR[name]}" '
                     f'stroke-width="{lw}" opacity="{op}"/>')

    # 图例
    lx, ly = 676, 112
    for i, name in enumerate(RUNS):
        y = ly + i * 25
        s.append(f'<line x1="{lx}" y1="{y}" x2="{lx + 22}" y2="{y}" '
                 f'stroke="{COLOR[name]}" stroke-width="3"/>')
        s.append(f'<text x="{lx + 28}" y="{y + 4}" font-size="11" fill="#38414A">'
                 f'{esc(LEGEND[name])}</text>')

    s.append(f'<text x="86" y="{top2 + ph + 34}" font-size="10.5" fill="#8894A0">'
             '请求百分位 (%)</text>')
    s.append('</svg>')
    path = os.path.join(OUT, "cdf.svg")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(s))
    print("saved:", path)


def dist_figure():
    W, H = 800, 400
    x0, y0 = 92, 300
    plot_h = 210
    gw = 118          # 每组宽度
    bw = 24
    vmax = 1250

    def Y(v):
        return y0 - plot_h * (v / float(vmax))

    s = []
    s.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
             f'viewBox="0 0 {W} {H}" font-family="Microsoft YaHei, Segoe UI, sans-serif">')
    s.append(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
    s.append('<text x="92" y="34" font-size="17" font-weight="600" fill="#12395e">'
             '图 2&#160;&#160;四个 SGLang 后端的请求分布</text>')
    s.append('<text x="92" y="56" font-size="11.5" fill="#666">'
             '虚线 = 完全均衡时的理想值 512（2048 / 4）</text>')

    for t in (0, 250, 500, 750, 1000, 1250):
        y = Y(t)
        s.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x0 + gw * 5 + 30}" y2="{y:.1f}" '
                 f'stroke="#E6EAEE" stroke-width="1"/>')
        s.append(f'<text x="{x0 - 8}" y="{y + 3.5:.1f}" font-size="10.5" fill="#8894A0" '
                 f'text-anchor="end">{t}</text>')

    yi = Y(512)
    s.append(f'<line x1="{x0}" y1="{yi:.1f}" x2="{x0 + gw * 5 + 30}" y2="{yi:.1f}" '
             f'stroke="#C0392B" stroke-width="1.4" stroke-dasharray="6,4"/>')

    for gi, name in enumerate(RUNS):
        gx = x0 + 18 + gi * gw
        base = COLOR[name]
        for bi in range(4):
            v = DIST[name][bi]
            bx = gx + bi * (bw + 5)
            by = Y(v)
            fill = base
            op = "1"
            if name == "C" and v == 1150:
                fill = "#C0392B"
            s.append(f'<rect x="{bx}" y="{by:.1f}" width="{bw}" height="{y0 - by:.1f}" '
                     f'fill="{fill}" opacity="{op}" rx="1.5"/>')
            if v >= 1000 or name in ("C", "D"):
                s.append(f'<text x="{bx + bw / 2:.1f}" y="{by - 4:.1f}" font-size="9.5" '
                         f'fill="#38414A" text-anchor="middle">{v}</text>')
        lbl = {"A": "A  p2c(5)", "B1": "B1  p2c(32)", "B2": "B2  p2c(64)",
               "C": "C  hash", "D": "D  自定义"}[name]
        s.append(f'<text x="{gx + 2 * (bw + 5) - 12:.1f}" y="{y0 + 38}" font-size="12.5" '
                 f'font-weight="600" fill="#38414A" text-anchor="middle">{esc(lbl)}</text>')

    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0 + gw * 5 + 30}" y2="{y0}" '
             f'stroke="#B9C2CC" stroke-width="1"/>')
    for bi in range(4):
        bx = x0 + 18 + bi * (bw + 5) + bw / 2
        s.append(f'<text x="{bx:.1f}" y="{y0 + 18}" font-size="10" fill="#8894A0" '
                 f'text-anchor="middle">b{bi}</text>')
    s.append(f'<text x="92" y="{y0 + 62}" font-size="10.5" fill="#8894A0">'
             'b0–b3 = backend-0…3（分别对应 :30000–:30003）</text>')
    s.append('</svg>')
    path = os.path.join(OUT, "backend_dist.svg")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(s))
    print("saved:", path)


if __name__ == "__main__":
    cdf_figure()
    dist_figure()
