# -*- coding: utf-8 -*-
"""生成 A4 报告用的窄版图（宽 690，图例置底，标签精简）。数据复用 make_figs。"""
import math
import os

from make_figs import COLOR, DIST, LAT, PS, TTFT, esc

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
RUNS = ["A", "B1", "B2", "C", "D"]
SHORT = {"A": "A  p2c(5)", "B1": "B1  p2c(32)", "B2": "B2  p2c(64)",
         "C": "C  hash(fb=0)", "D": "D  自定义"}


def cdf_report():
    W = 690
    x0, x1 = 64, 634
    lo, hi = math.log10(10.0), math.log10(40000.0)
    ph = 166
    top1, top2 = 56, 288
    H = 582

    def X(p):
        return x0 + (p / 100.0) * (x1 - x0)

    def Y(v, top):
        f = (math.log10(max(v, 1.0)) - lo) / (hi - lo)
        return top + ph * (1.0 - f)

    s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
         f'viewBox="0 0 {W} {H}" font-family="Microsoft YaHei, Segoe UI, sans-serif">',
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         '<text x="64" y="24" font-size="11" fill="#666">'
         '横轴 = 请求百分位；纵轴 = 耗时（对数刻度，ms）；曲线越靠左下越好</text>']

    yticks = [10, 30, 100, 300, 1000, 3000, 10000, 30000]
    for title, data, top in (("TTFT（首 token 延迟）", TTFT, top1),
                             ("端到端延迟", LAT, top2)):
        s.append(f'<text x="64" y="{top - 10}" font-size="12.5" font-weight="600" '
                 f'fill="#12395e">{esc(title)}</text>')
        for t in yticks:
            y = Y(t, top)
            if y < top - 1 or y > top + ph + 1:
                continue
            s.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x1}" y2="{y:.1f}" '
                     f'stroke="#E6EAEE" stroke-width="1"/>')
            s.append(f'<text x="{x0 - 7}" y="{y + 3.5:.1f}" font-size="10.5" fill="#8894A0" '
                     f'text-anchor="end">{t}</text>')
        s.append(f'<line x1="{x0}" y1="{top + ph}" x2="{x1}" y2="{top + ph}" '
                 f'stroke="#B9C2CC" stroke-width="1"/>')
        s.append(f'<line x1="{x0}" y1="{top}" x2="{x0}" y2="{top + ph}" '
                 f'stroke="#B9C2CC" stroke-width="1"/>')
        for p in (0, 25, 50, 75, 95, 100):
            x = X(p)
            s.append(f'<line x1="{x:.1f}" y1="{top + ph}" x2="{x:.1f}" y2="{top + ph + 4}" '
                     f'stroke="#B9C2CC" stroke-width="1"/>')
            s.append(f'<text x="{x:.1f}" y="{top + ph + 16}" font-size="10.5" fill="#8894A0" '
                     f'text-anchor="middle">{p}</text>')
        for p, col in ((50, "#C9A227"), (95, "#C0392B")):
            x = X(p)
            s.append(f'<line x1="{x:.1f}" y1="{top}" x2="{x:.1f}" y2="{top + ph}" '
                     f'stroke="{col}" stroke-width="1" stroke-dasharray="4,3" opacity="0.6"/>')
        for name in RUNS:
            pts = " ".join(f"{X(PS[i]):.1f},{Y(data[name][i], top):.1f}" for i in range(len(PS)))
            lw = 2.5 if name in ("C", "D") else 1.6
            s.append(f'<polyline points="{pts}" fill="none" stroke="{COLOR[name]}" '
                     f'stroke-width="{lw}"/>')

    s.append(f'<text x="{x0}" y="{top2 + ph + 36}" font-size="10.5" fill="#8894A0">'
             '请求百分位 (%)</text>')
    for i, name in enumerate(RUNS):
        col = i // 3
        row = i % 3
        lx = 64 + col * 320
        ly = 512 + row * 22
        s.append(f'<line x1="{lx}" y1="{ly}" x2="{lx + 20}" y2="{ly}" '
                 f'stroke="{COLOR[name]}" stroke-width="3"/>')
        s.append(f'<text x="{lx + 26}" y="{ly + 4}" font-size="11" fill="#38414A">'
                 f'{esc(SHORT[name])}</text>')
    s.append('</svg>')
    p = os.path.join(OUT, "cdf_report.svg")
    open(p, "w", encoding="utf-8").write("\n".join(s))
    print("saved:", p)


def dist_report():
    W, H = 690, 284
    x0, y0 = 74, 210
    plot_h = 160
    gw = 106
    bw = 20
    vmax = 1250

    def Y(v):
        return y0 - plot_h * (v / float(vmax))

    s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
         f'viewBox="0 0 {W} {H}" font-family="Microsoft YaHei, Segoe UI, sans-serif">',
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         '<text x="74" y="24" font-size="11" fill="#666">'
         '虚线 = 完全均衡时的理想值 512（2048 ÷ 4）</text>']
    for t in (0, 250, 500, 750, 1000, 1250):
        y = Y(t)
        s.append(f'<line x1="{x0}" y1="{y:.1f}" x2="{x0 + gw * 5 + 24}" y2="{y:.1f}" '
                 f'stroke="#E6EAEE" stroke-width="1"/>')
        s.append(f'<text x="{x0 - 7}" y="{y + 3.5:.1f}" font-size="10.5" fill="#8894A0" '
                 f'text-anchor="end">{t}</text>')
    yi = Y(512)
    s.append(f'<line x1="{x0}" y1="{yi:.1f}" x2="{x0 + gw * 5 + 24}" y2="{yi:.1f}" '
             f'stroke="#C0392B" stroke-width="1.3" stroke-dasharray="6,4"/>')
    for gi, name in enumerate(RUNS):
        gx = x0 + 14 + gi * gw
        for bi in range(4):
            v = DIST[name][bi]
            bx = gx + bi * (bw + 4)
            by = Y(v)
            fill = "#C0392B" if (name == "C" and v == 1150) else COLOR[name]
            s.append(f'<rect x="{bx}" y="{by:.1f}" width="{bw}" height="{y0 - by:.1f}" '
                     f'fill="{fill}" rx="1.5"/>')
            if v >= 1000 or name in ("C", "D"):
                s.append(f'<text x="{bx + bw / 2:.1f}" y="{by - 4:.1f}" font-size="9.5" '
                         f'fill="#38414A" text-anchor="middle">{v}</text>')
        s.append(f'<text x="{gx + 2 * (bw + 4) - 10:.1f}" y="{y0 + 38}" font-size="12" '
                 f'font-weight="600" fill="#38414A" text-anchor="middle">'
                 f'{esc(SHORT[name])}</text>')
    s.append(f'<line x1="{x0}" y1="{y0}" x2="{x0 + gw * 5 + 24}" y2="{y0}" '
             f'stroke="#B9C2CC" stroke-width="1"/>')
    for bi in range(4):
        bx = x0 + 14 + bi * (bw + 4) + bw / 2
        s.append(f'<text x="{bx:.1f}" y="{y0 + 17}" font-size="10" fill="#8894A0" '
                 f'text-anchor="middle">b{bi}</text>')
    s.append(f'<text x="74" y="{y0 + 62}" font-size="10.5" fill="#8894A0">'
             'b0–b3 = backend-0…3（分别对应 :30000–:30003）</text>')
    s.append('</svg>')
    p = os.path.join(OUT, "dist_report.svg")
    open(p, "w", encoding="utf-8").write("\n".join(s))
    print("saved:", p)


if __name__ == "__main__":
    cdf_report()
    dist_report()
