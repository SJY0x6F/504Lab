# -*- coding: utf-8 -*-
"""生成报告用的「请求处理与路由流程图」（SVG）。"""
import os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
os.makedirs(OUT, exist_ok=True)

W, H = 690, 716
TOP = 36
MX, MW = 34, 296
SX, SW = 350, 306
BH = 46
GAP = 28


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


STEPS = [
    ("客户端 run_workload.py", "POST /generate，携带 X-Session-Id 等三个请求头"),
    ("Ray Serve HTTP Proxy（:8000）", "构造 RequestMetadata，session_id ← X-Session-Id"),
    ("RequestRouter.choose_replicas(...)", "使用哪种路由器由部署配置决定（见右栏）"),
    ("返回候选链", "[[首选], [备选1], [备选2], [备选3]]"),
    ("投递请求", "首选被拒（队列满 64）→ 立即溢出到下一级"),
    ("Replica i（位于 worker i）", "固定转发到 127.0.0.1 : 30000 + idx"),
    ("SGLang 后端 i（独占 GPU i）", "RadixCache 前缀匹配 → Prefill / Decode"),
    ("回传 SSE 流", "原样转发 ＋ 注入三个 X-Ray-* / X-SGLang-* 头"),
    ("客户端记录逐请求指标", "ttft_s、tpot_s、latency_s、cached_tokens、backend"),
]


def box(y, title, detail, fill, stroke, tfill="#0f2b45"):
    x = MX
    s = [f'<rect x="{x}" y="{y}" width="{MW}" height="{BH}" rx="6" fill="{fill}" '
         f'stroke="{stroke}" stroke-width="1.4"/>',
         f'<text x="{x + 12}" y="{y + 20}" font-size="11.6" font-weight="600" '
         f'fill="{tfill}">{esc(title)}</text>',
         f'<text x="{x + 12}" y="{y + 36}" font-size="9" fill="#5a6673">'
         f'{esc(detail)}</text>']
    return "\n".join(s)


def arrow(y1, y2):
    return (f'<line x1="{MX + MW / 2}" y1="{y1}" x2="{MX + MW / 2}" y2="{y2 - 5}" '
            f'stroke="#9FB0BF" stroke-width="1.6"/>'
            f'<path d="M{MX + MW / 2 - 4},{y2 - 5} L{MX + MW / 2},{y2} '
            f'L{MX + MW / 2 + 4},{y2 - 5} Z" fill="#9FB0BF"/>')


def panel():
    y = TOP
    s = [f'<rect x="{SX}" y="{y}" width="{SW}" height="{BH * 9 + GAP * 8}" rx="8" '
         f'fill="#f7fafc" stroke="#cbd6df" stroke-width="1.2"/>',
         f'<text x="{SX + 14}" y="{y + 24}" font-size="12" font-weight="600" '
         f'fill="#12395e">路由器决策：本轮比较的三种配置</text>']

    blocks = [
        ("#2171B5", "#eaf3fb", "默认 P2C（A / B1 / B2）",
         ["随机挑 2 个副本 → 询问队列深度 → 选较短者；",
          "完全按负载均衡决策，不利用前缀信息"]),
        ("#E6550D", "#fdf2e9", "ConsistentHashRouter（C）",
         ["按 session_id 在 100×4 vnode 哈希环上定位唯一主副本；",
          "num_fallback_replicas = 0 ⇒ 被拒后只能原地重试"]),
        ("#0F6E56", "#eaf6f1", "AffinityAwareRouter（D，本次实现）",
         ["① 环上取亲和副本 A",
          "② 并发问全部 4 个副本的队列深度 q",
          "③ 若 q_A &gt; 1.5 × min(q) + 2 → 改投最闲副本",
          "　　否则仍投 A（保住缓存复用）",
          "④ 返回 4 级候选链，被拒后有路可退"]),
    ]
    by = y + 40
    for color, fill, title, lines in blocks:
        h = 26 + len(lines) * 15 + 8
        s.append(f'<rect x="{SX + 12}" y="{by}" width="{SW - 24}" height="{h}" rx="5" '
                 f'fill="{fill}" stroke="{color}" stroke-width="1.2"/>')
        s.append(f'<rect x="{SX + 12}" y="{by}" width="3.5" height="{h}" rx="1.5" fill="{color}"/>')
        s.append(f'<text x="{SX + 22}" y="{by + 17}" font-size="10.5" font-weight="600" '
                 f'fill="{color}">{esc(title)}</text>')
        for i, ln in enumerate(lines):
            s.append(f'<text x="{SX + 22}" y="{by + 33 + i * 15}" font-size="8.8" '
                     f'fill="#4a5560">{ln}</text>')
        by += h + 12

    by += 6
    kh = 76
    s.append(f'<rect x="{SX + 12}" y="{by}" width="{SW - 24}" height="{kh}" rx="5" '
             f'fill="#ffffff" stroke="#cbd6df" stroke-width="1.1" stroke-dasharray="4,3"/>')
    s.append(f'<text x="{SX + 22}" y="{by + 17}" font-size="10" font-weight="600" '
             f'fill="#12395e">关键点</text>')
    notes = [
        "· 亲和副本由 X-Session-Id（= 前缀族 ID）决定；",
        "· 队列深度由 RunningReplica.get_queue_len() 实时获取；",
        "· 路由器只使用当前请求与当前服务状态，不读取未来请求；",
        "· 三组配置共用同一入口、负载与后端拓扑，差异只在路由决策。",
    ]
    for i, ln in enumerate(notes):
        s.append(f'<text x="{SX + 22}" y="{by + 33 + i * 13}" font-size="8.6" '
                 f'fill="#5a6673">{esc(ln)}</text>')
    return "\n".join(s)


def main():
    s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
         f'viewBox="0 0 {W} {H}" font-family="Microsoft YaHei, Segoe UI, sans-serif">',
         f'<rect width="{W}" height="{H}" fill="#ffffff"/>',
         '<text x="34" y="24" font-size="10.5" fill="#666">'
         'Client → Ray Serve HTTP Proxy → Replica 0..3 → SGLang 0..3</text>']

    y = TOP
    for i, (t, d) in enumerate(STEPS):
        last = i == len(STEPS) - 1
        if i == 2:
            fill, stroke = "#eaf6f1", "#0F6E56"
        elif last:
            fill, stroke = "#eef3f8", "#7f93a6"
        else:
            fill, stroke = "#ffffff", "#c3cfd9"
        s.append(box(y, t, d, fill, stroke))
        if not last:
            s.append(arrow(y + BH, y + BH + GAP))
        y += BH + GAP

    s.append(panel())
    s.append("</svg>")
    p = os.path.join(OUT, "flowchart_report.svg")
    open(p, "w", encoding="utf-8").write("\n".join(s))
    print("saved:", p)


if __name__ == "__main__":
    main()
