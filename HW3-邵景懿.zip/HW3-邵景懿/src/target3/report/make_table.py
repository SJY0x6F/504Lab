# -*- coding: utf-8 -*-
"""生成 HW3 主表图片（Pillow，无需 matplotlib）。"""
import os
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "figures")
os.makedirs(OUT, exist_ok=True)

FONT_CANDIDATES = [
    (r"C:\Windows\Fonts\msyhbd.ttc", r"C:\Windows\Fonts\msyh.ttc"),
    (r"C:\Windows\Fonts\msyh.ttc", r"C:\Windows\Fonts\msyh.ttc"),
    (r"C:\Windows\Fonts\simhei.ttf", r"C:\Windows\Fonts\simhei.ttf"),
]


def load_fonts(bold_size, body_size):
    for bpath, rpath in FONT_CANDIDATES:
        try:
            return ImageFont.truetype(bpath, bold_size), ImageFont.truetype(rpath, body_size)
        except Exception:
            continue
    raise RuntimeError("找不到中文字体")


HEADERS = ["组别", "配置", "成功率", "吞吐量\n(req/s)", "缓存命中率",
           "实际 Prefill\ntoken 数", "TTFT p95\n(ms)", "端到端 p95\n(ms)",
           "四个后端请求分布"]

ROWS = [
    ["A", "默认 P2C，max_ongoing=5", "2048/2048", "44.05", "88.08%", "385,279", "16,676", "17,081", "517/504/522/505"],
    ["B1", "调优 P2C，max_ongoing=32", "2048/2048", "54.66", "88.08%", "385,535", "7,309", "9,609", "481/531/517/519"],
    ["B2", "调优 P2C，max_ongoing=64（选定）", "2048/2048", "66.64", "88.02%", "387,325", "1,632", "4,673", "496/510/540/502"],
    ["C", "ConsistentHash，fallback=0", "2048/2048", "41.97", "95.79%", "136,188", "18,813", "21,202", "217/1150/378/303"],
    ["D", "AffinityAwareRouter（自定义）", "2048/2048", "68.14", "90.00%", "323,453", "1,326", "4,094", "497/555/513/483"],
]

# 每列「谁最好」的方向：1=越大越好, -1=越小越好, 0=不比较
BEST_DIR = [0, 0, 0, 1, 1, -1, -1, -1, 0]
NUMCOL = {3, 4, 5, 6, 7}


def parse(v, ci):
    if ci == 4:
        return float(v.rstrip("%"))
    return float(v.replace(",", ""))


def main():
    fb, fr = load_fonts(25, 23)
    fhb, fhr = load_fonts(23, 21)

    pad_x, pad_y = 20, 16
    col_w = []
    for ci, h in enumerate(HEADERS):
        w = max(fhb.getbbox(h.replace("\n", ""))[2] - fhb.getbbox(h.replace("\n", ""))[0],
                fhr.getbbox(h)[2] - fhr.getbbox(h)[0])
        for r in ROWS:
            t = r[ci]
            w = max(w, fr.getbbox(t)[2] - fr.getbbox(t)[0])
        col_w.append(w + pad_x * 2)

    line_h = 34
    header_lines = [len(h.split("\n")) for h in HEADERS]
    header_h = max(header_lines) * line_h + pad_y * 2
    row_h = 58

    W = sum(col_w) + 2
    H = header_h + row_h * len(ROWS) + 2

    img = Image.new("RGB", (W, H), "#FFFFFF")
    d = ImageDraw.Draw(img)

    # 表头
    d.rectangle([0, 0, W, header_h], fill="#12395e")
    x = 1
    for ci, h in enumerate(HEADERS):
        lines = h.split("\n")
        ty = (header_h - len(lines) * line_h) / 2 + 2
        for ln in lines:
            tw = fhb.getbbox(ln)[2] - fhb.getbbox(ln)[0]
            d.text((x + (col_w[ci] - tw) / 2, ty), ln, font=fhb, fill="#FFFFFF")
            ty += line_h
        x += col_w[ci]

    # 最优值
    best = {}
    for ci in range(len(HEADERS)):
        if BEST_DIR[ci] == 0:
            continue
        vals = [parse(r[ci], ci) for r in ROWS]
        best[ci] = max(vals) if BEST_DIR[ci] == 1 else min(vals)

    # 数据行
    y = header_h
    for ri, r in enumerate(ROWS):
        if ri % 2 == 1:
            d.rectangle([1, y, W - 1, y + row_h], fill="#F5F8FA")
        d.line([1, y, W - 1, y], fill="#DDE4EA", width=1)
        x = 1
        for ci, t in enumerate(r):
            is_best = ci in best and abs(parse(r[ci], ci) - best[ci]) < 1e-9
            f = fb if is_best else fr
            color = "#0F6E56" if is_best else ("#12395e" if ci <= 1 else "#333333")
            tw = f.getbbox(t)[2] - f.getbbox(t)[0]
            if ci == 0:
                d.text((x + pad_x, y + (row_h - 26) / 2), t, font=f, fill=color)
            else:
                d.text((x + (col_w[ci] - tw) / 2, y + (row_h - 26) / 2), t,
                       font=f, fill=color)
            x += col_w[ci]
        y += row_h
    d.line([1, y, W - 1, y], fill="#B9C2CC", width=1)

    out = os.path.join(OUT, "table.png")
    img.save(out)
    print("saved:", out, img.size)


if __name__ == "__main__":
    main()
