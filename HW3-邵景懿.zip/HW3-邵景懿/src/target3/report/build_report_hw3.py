# -*- coding: utf-8 -*-
"""生成 HW3 报告 HTML（矢量图内联，含主表）。"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(HERE, "figures")
OUT = os.path.join(HERE, "report.html")


def inline_svg(name):
    svg = open(os.path.join(FIG, name), encoding="utf-8").read()
    svg = re.sub(r'\swidth="\d+"\sheight="\d+"', "", svg, count=1)
    svg = svg.replace("<svg ", '<svg style="width:100%;height:auto;display:block" ', 1)
    return svg


ROWS = [
    ("A", "默认 P2C，max_ongoing_requests = 5", "2048/2048", "44.05", "88.08%",
     "385,279", "16,676", "17,081", "517/504/522/505", set()),
    ("B1", "调优 P2C，max_ongoing_requests = 32", "2048/2048", "54.66", "88.08%",
     "385,535", "7,309", "9,609", "481/531/517/519", set()),
    ("B2", "调优 P2C，max_ongoing_requests = <b>64（选定）</b>", "2048/2048", "66.64",
     "88.02%", "387,325", "1,632", "4,673", "496/510/540/502", {3}),
    ("C", "ConsistentHashRouter，num_fallback_replicas = 0", "2048/2048", "41.97",
     "95.79%", "136,188", "18,813", "21,202", "217/1150/378/303", {4, 5}),
    ("D", "AffinityAwareRouter（自定义，前缀亲和 + 队列兜底）", "2048/2048", "68.14",
     "90.00%", "323,453", "1,326", "4,094", "497/555/513/483", {3, 6, 7}),
]


def main_table():
    head = ["组别", "配置", "成功率", "吞吐量<br>(req/s)", "缓存命中率",
            "实际 Prefill<br>token 数", "TTFT p95<br>(ms)", "端到端 p95<br>(ms)",
            "四个后端<br>请求分布"]
    out = ['<table>', "<thead><tr>" + "".join(f"<th>{h}</th>" for h in head) + "</tr></thead>",
           "<tbody>"]
    for r in ROWS:
        tds = []
        for i, v in enumerate(r[:9]):
            cls = []
            if i == 1:
                cls.append("l")
            if i in r[9]:
                cls.append("best")
            c = f' class="{" ".join(cls)}"' if cls else ""
            tds.append(f"<td{c}>{v}</td>")
        out.append("<tr>" + "".join(tds) + "</tr>")
    out.append("</tbody></table>")
    return "\n".join(out)


CSS = """
@page { size: A4; margin: 15mm 14mm 14mm; }
* { box-sizing: border-box; }
body { font-family: "Microsoft YaHei", "Segoe UI", sans-serif; font-size: 10.5pt;
       line-height: 1.7; color: #23282d; margin: 0; }
h1 { font-size: 17pt; color: #12395e; margin: 0 0 4px; text-align: center; }
.meta { text-align: center; font-size: 9pt; color: #777; margin: 0 0 16px;
        padding-bottom: 10px; border-bottom: 2px solid #12395e; }
h2 { font-size: 12.5pt; color: #12395e; margin: 20px 0 8px; padding: 5px 0 5px 10px;
     border-left: 4px solid #185FA5; background: #f4f8fb; page-break-after: avoid; }
h3 { font-size: 11pt; color: #185FA5; margin: 13px 0 5px; page-break-after: avoid; }
p { margin: 6px 0; text-align: justify; }
ul, ol { margin: 6px 0 6px 4px; padding-left: 20px; }
li { margin: 3px 0; }
table { border-collapse: collapse; width: 100%; font-size: 8pt; margin: 8px 0 4px;
        page-break-inside: avoid; }
th { background: #12395e; color: #fff; padding: 6px 4px; font-weight: 600;
     line-height: 1.35; border: 1px solid #12395e; }
td { padding: 5px 4px; border-bottom: 1px solid #DDE4EA; text-align: center;
     border-left: 1px solid #EDF1F4; border-right: 1px solid #EDF1F4; }
td.l { text-align: left; }
tbody tr:nth-child(even) td { background: #F5F8FA; }
.best { color: #0F6E56; font-weight: 700; }
.lead { font-weight: 700; color: #12395e; }
.cap { font-size: 8.5pt; color: #666; text-align: center; margin: 4px 0 14px; }
figure { margin: 12px 0 6px; page-break-inside: avoid; }
code, .mono { font-family: Consolas, "Courier New", monospace; font-size: 9pt;
              background: #F2F5F7; padding: 1px 4px; border-radius: 2px; color: #12395e; }
pre { font-family: Consolas, "Courier New", monospace; font-size: 8.5pt;
      background: #F7F9FA; border-left: 3px solid #185FA5; padding: 8px 10px;
      margin: 8px 0; line-height: 1.5; white-space: pre-wrap; color: #2c3e50; }
.box { background: #FFF9E6; border: 1px solid #E8D48B; border-radius: 4px;
       padding: 10px 12px; margin: 10px 0; font-size: 9.5pt; }
.box b { color: #8a6d1a; }
.kv { font-size: 9.5pt; }
.todo { background: #FDECEA; border: 1px solid #E8A79B; border-radius: 4px;
        padding: 12px; margin: 10px 0; font-size: 9.5pt; color: #8a2c1a; }
"""


def build():
    cdf = inline_svg("cdf_report.svg")
    dist = inline_svg("dist_report.svg")
    ganshou_html = open(os.path.join(HERE, "作业感受.html"), encoding="utf-8").read()
    flowchart = inline_svg("flowchart_report.svg")

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<title>挑战三：比较并改进 Ray Serve 路由</title>
<style>{CSS}</style></head><body>

<h1>挑战三：比较并改进 Ray Serve 路由</h1>
<p class="meta">邵景懿&nbsp;&nbsp;｜&nbsp;&nbsp;2026 年 10 月 5 日</p>

<h2>一、实验环境与设置</h2>
<table>
<thead><tr><th style="width:22%">项目</th><th>配置</th></tr></thead>
<tbody>
<tr><td class="l">硬件</td><td class="l">4 × RTX 4090 24GB（同一台服务器），64 vCPU / 480GB 内存</td></tr>
<tr><td class="l">模型</td><td class="l">Qwen/Qwen3-0.6B（bf16，权重 1.18 GB）</td></tr>
<tr><td class="l">推理服务</td><td class="l">SGLang 0.5.14，<b>4 个实例</b>分别独占 GPU 0–3，端口 30000–30003，<code>--mem-fraction-static 0.85</code></td></tr>
<tr><td class="l">服务编排</td><td class="l">Ray 2.56.0：1 个 head 节点 + 4 个逻辑 worker 节点（<code>ray.cluster_utils.Cluster</code>）</td></tr>
<tr><td class="l">路由层</td><td class="l">Ray Serve：1 个 Deployment、<code>num_replicas=4</code>，每个 Replica 钉在<b>不同</b> worker 节点，固定转发到对应 SGLang</td></tr>
<tr><td class="l">负载</td><td class="l"><code>mooncake_prefix_workload_v2_seed2026.jsonl</code>，SHA-256 <code>f154ba95…75b03</code>（校验与课程发布一致）</td></tr>
<tr><td class="l">压测端</td><td class="l"><code>run_workload.py --policy serve --max-in-flight 2048</code>，与 Ray Serve 同机</td></tr>
</tbody></table>

<p class="kv">架构为 <b>Client → Ray Serve HTTP Proxy → Replica 0..3 → SGLang 0..3</b>。
Ray Serve 应用在初始化时用 <code>ray.get_runtime_context().get_node_id()</code> 反查本 Replica 所在节点在集群中的序号，
固定转发到 <code>127.0.0.1:30000+idx</code>，从而保证「四个 Replica 分别访问四个独立的 SGLang 后端」；
同时把 SGLang 的 SSE 流原样回传，并在响应头注入 <code>X-Ray-Replica-ID</code> /
<code>X-Ray-Node-ID</code> / <code>X-SGLang-Backend</code>。</p>

<p class="kv"><b>每轮实验流程</b>：重新部署对应配置的 Ray Serve 应用 → 对 4 个 SGLang 后端逐个
<code>POST /flush_cache</code>（均返回 200）→ 流量发生器先发 64 条预热、再发 2048 条测量请求 →
核对 <code>summary.json</code>。</p>

<h2>二、请求处理与路由流程</h2>

<p>图 1 给出一次请求在目标三服务链路中的完整路径。请求由流量发生器发到 Ray Serve 的 HTTP 入口，
代理先构造 <code>RequestMetadata</code>（其中 <code>session_id</code> 取自请求头
<code>X-Session-Id</code>），再交给该 Deployment 配置的请求路由器。路由器返回一个<b>按优先级排序的候选链</b>，
框架按顺序尝试投递——首选副本若因队列满而拒绝，请求会立即溢出到下一级。请求落到某个 Replica 后，
由它固定转发给对应的那一个 SGLang 后端；SGLang 完成 RadixCache 前缀匹配与 Prefill / Decode，
把 SSE 流原样交回，Replica 在响应头注入三个 <code>X-Ray-*</code> / <code>X-SGLang-*</code> 标识，
客户端据此把每条请求的路由位置与逐请求指标写进 CSV。</p>

<p>本报告比较的三种路由器都挂在图 1 的第 3 步上，差别只在「返回什么样的候选链」：
默认 p2c 只看负载、完全不用前缀信息；一致性哈希只看 session 亲和，而且候选链只有 1 级；
D 则先用哈希定位亲和副本，再用实时队列深度决定是否让路，同时给出完整的 4 级候选链。</p>

<figure>
{flowchart}
<div class="cap">图 1&nbsp;&nbsp;一次请求在目标三服务链路中的处理与路由流程</div>
</figure>

<h2>三、四组对照结果</h2>

{main_table()}
<div class="cap">表 1&nbsp;&nbsp;A、两个 B 候选、C、D 五轮实验主表（绿色为该项最优）</div>

<p class="kv"><b>完成标准核对</b>：五轮全部 <code>successful = 2048 / failed = 0 / incomplete = 0</code>、
<code>warmup 64 / 0 / 0</code>、<code>validation_errors = []</code>；<code>replica / node / backend</code>
三项分布<b>各覆盖 4 项</b>，即四个 Replica 分别落在四个节点、分别使用四个 SGLang 后端；
实验期间 1 个 head 节点与 4 个 worker 节点全程活跃。</p>

<figure>
{cdf}
<div class="cap">图 2&nbsp;&nbsp;五种配置的 TTFT 与端到端延迟累积分布（纵轴对数刻度，曲线越靠左下越好）</div>
</figure>

<figure>
{dist}
<div class="cap">图 3&nbsp;&nbsp;四个 SGLang 后端的请求分布（虚线为完全均衡时的理想值 512）</div>
</figure>

<h2>四、默认值与 B 选定值为何表现不同</h2>

<p><code>max_ongoing_requests</code> 是 Ray Serve 路由器允许<b>每个 Replica 同时在飞的请求数上限</b>，
它决定入口的并发容量，与 GPU 算力无关。</p>

<ul>
<li><b>A（= 5）</b>：全场并发上限 = 4 × 5 = <b>20</b>。而负载峰值 120 req/s ÷ 4 副本 = 每副本 30 req/s，
单请求服务时间约 1.5 s，因此需要约 <b>45</b> 个并发才能跟上。20 并发只够支撑约 13 req/s，
请求大量堵在 Serve 路由器里：<code>burst</code> 阶段 TTFT p95 达 <b>13.4 s</b>，
全程 <code>elapsed_s</code> = 46.5 s（计划 29.5 s，<b>积压 57%</b>）。</li>
<li><b>B2（= 64）</b>：容量约 43 req/s/副本，超过峰值需求。<code>elapsed_s</code> 降到 <b>30.7 s</b>
（几乎不积压），TTFT p95 降到 <b>1.63 s</b>（下降 10 倍），吞吐从 44.1 升到 66.6 req/s。</li>
</ul>

<p><b>代价是 TPOT</b>：<code>tpot_s</code> 均值从 3.0 ms 升到 14.0 ms。原因是并发放宽后，
同一批进入 SGLang 的请求更多、批更大，虽然总吞吐更高，但<b>每个 token 的生成变慢</b>。
这是典型的吞吐—延迟权衡：调大并发牺牲了请求进入服务后的实时性，换来的是不再排队。</p>

<p><b>选定 B = 64 的依据</b>：TTFT p95（1.63 s）完胜 32（7.31 s），吞吐更高（66.6 vs 54.7 req/s），
缓存命中率几乎不变（88.02% vs 88.08%），仅 TPOT 从 11.7 ms 微升到 14.0 ms；
而负载总时长只有 29.5 s，64 并发已能让系统"跑完全程不积压"，继续调大没有额外收益。</p>

<h2>五、前缀亲和为什么同时带来缓存收益和热点</h2>

<h3>5.1 收益：缓存复用</h3>
<p>C 组用 <code>ConsistentHashRouter</code> 按 <code>X-Session-Id</code>（即前缀族 ID）做一致性哈希，
<b>同一族的请求恒定落到同一个后端</b>。于是每个族那 ≥1024 token 的共享前缀，
只需在<b>一个</b>后端的 RadixCache 里建立并维护一次；而在 A/B（p2c）下同一族请求会散到 4 个后端，
<b>每个后端都要把同一段前缀各算一遍、各存一份</b>。实测差异很直接：</p>

<table>
<thead><tr><th style="width:34%">指标</th><th>B2（负载均衡）</th><th>C（前缀亲和）</th></tr></thead>
<tbody>
<tr><td class="l">缓存命中率</td><td>88.02%</td><td class="best">95.79%</td></tr>
<tr><td class="l">实际 Prefill token 数</td><td>387,325</td><td class="best">136,188（↓ 65%）</td></tr>
</tbody></table>

<h3>5.2 热点：请求量本来就极不均</h3>
<p>负载的请求量按族分布高度倾斜——<b>1 个超热族 768 条</b>、7 个热族、24 个中热族、32 个冷族。
一致性哈希把那个超热族整体映射到某一个后端之后，该后端要独自承担 <b>1150</b> 条（占总数 56%），
而最冷的后端只有 217 条，<b>偏斜达 5.3 倍</b>。</p>

<p>后果是极端的<b>双峰分布</b>：C 的 TTFT <b>中位数只有 0.22 s</b>（命中缓存、瞬间返回），
但 <b>p95 高达 18.8 s</b>（落到热点后端的请求在排队）。端到端 p95 = 21.2 s，
比均衡的 B2 差 4.5 倍；吞吐也从 66.6 掉到 42.0 req/s。</p>

<p>图 2 中可以清楚看到：C（橙线）在 p50 处位于所有曲线<b>最低</b>，但从 p60 起急剧上翘，
到 p99 反而成了<b>最差</b>的一条；而 B2（深蓝）与 D（绿）的尾部平坦得多。
图 3 中那根冲到 1150 的深红柱子，就是这一偏斜的直接体现。</p>

<h2>六、D 的改进：信号、规则、收益与代价</h2>

<h3>6.1 使用的信号（仅当前请求 + 当前服务状态）</h3>
<ol>
<li><b>当前请求的前缀族标识</b> <code>X-Session-Id</code>（经 Ray 的 <code>RequestMetadata.session_id</code> 暴露给路由器）；</li>
<li><b>各副本的实时排队深度</b>：通过 <code>RunningReplica.get_queue_len()</code> 向副本发控制消息，
获取其当前在飞请求数。</li>
</ol>
<p>整个过程<b>没有使用任何未来请求的信息</b>，也不依赖负载的统计特征，符合"路由器只能使用当前请求和当前服务状态"的约束。</p>

<h3>6.2 规则</h3>
<pre>① 在一致性哈希环上取「亲和副本」A          ← 复用 Ray 的 ConsistentHashRouter 环（100 vnode / 副本）
② 并发查询全部 4 个副本的当前队列深度 q
③ 若 q_A &gt; ratio × min(q) + slack            ← ratio = 1.5, slack = 2
       则改投队列最短的副本（让路）
   否则 仍投 A（保住缓存复用）
④ 返回完整的 4 级候选链                      ← num_fallback_replicas = 3</pre>
<p>第 ③ 步中的 <code>slack</code> 是必需的：若只写 <code>q_A &gt; min(q)</code>，
在零负载时（例如 q_A = 1、min = 0）也会被误判为过载而乱跳，反而破坏亲和性。</p>

<h3>6.3 改善了什么</h3>
<table>
<thead><tr><th style="width:32%">指标</th><th>C（纯前缀亲和）</th><th>D（本次实现）</th><th>变化</th></tr></thead>
<tbody>
<tr><td class="l">四个后端请求分布</td><td>217/1150/378/303（偏斜 5.3×）</td>
    <td class="best">497/555/513/483（偏斜 1.15×）</td><td>基本拉平</td></tr>
<tr><td class="l">TTFT p95</td><td>18,813 ms</td><td class="best">1,326 ms</td><td><b>↓ 14 倍</b></td></tr>
<tr><td class="l">端到端 p95</td><td>21,202 ms</td><td class="best">4,094 ms</td><td>↓ 5.2 倍</td></tr>
<tr><td class="l">吞吐量</td><td>41.97 req/s</td><td class="best">68.14 req/s</td><td>↑ 62%</td></tr>
<tr><td class="l">全程耗时 elapsed_s</td><td>48.80 s</td><td class="best">30.06 s</td><td>基本不积压</td></tr>
</tbody></table>

<p>同时相对<b>同样负载均衡</b>的 B2，D 还保留了明显更多的缓存收益：</p>
<table>
<thead><tr><th style="width:32%">指标</th><th>B2（负载均衡）</th><th>D（本次实现）</th></tr></thead>
<tbody>
<tr><td class="l">缓存命中率</td><td>88.02%</td><td class="best">90.00%</td></tr>
<tr><td class="l">实际 Prefill token 数</td><td>387,325</td><td class="best">323,453（↓ 16%）</td></tr>
<tr><td class="l">吞吐量</td><td>66.64 req/s</td><td class="best">68.14 req/s</td></tr>
<tr><td class="l">TTFT p95</td><td>1,632 ms</td><td class="best">1,326 ms</td></tr>
<tr><td class="l">端到端 p95</td><td>4,673 ms</td><td class="best">4,094 ms</td></tr>
</tbody></table>
<p>即 <b>D 在每一项上都不劣于 B2，同时在缓存复用上明显更好</b>。</p>

<h3>6.4 代价</h3>
<ul>
<li><b>缓存命中率比 C 低 5.8 个百分点</b>（95.79% → 90.00%），实际 Prefill 从 136k 升到 323k；</li>
<li>TPOT 略升（9.3 → 12.0 ms），因为负载更均衡后各后端的批更大。</li>
</ul>
<p>一句话：<b>用一部分缓存复用，换来了不过载。</b></p>

<h3>6.5 一个重要的机制归因</h3>
<p>日志统计显示，D 的"主动改投"只发生了 <b>7.2%</b>（每个代理 <code>600 routes, 43 overflowed</code>）。
但仅靠这点改投不足以把分布从 C 的 <code>217/1150/378/303</code> 搬到 D 的
<code>497/555/513/483</code>（那需要挪动约 600 条请求）。真正的缺口由<b>第二层机制</b>填补：</p>

<div class="box">
<b>C 的 <code>num_fallback_replicas = 0</code> 意味着路由器只返回 1 个候选。</b>
当该副本因队列满（<code>max_ongoing_requests = 64</code>）而拒绝时，请求只能<b>原地退避、重试同一个副本</b>
——这正是 C 尾部出现 18.8 s 的根因。<br>
<b>D 返回 4 级候选链</b>：主副本一旦拒绝，请求<b>立即溢出到下一个副本</b>，不再空等。
</div>

<p>也就是说，D 的收益来自「主动按队列深度改投（7%）」+「被拒绝时有一条完整的退路（贡献更大）」。
这也解释了为什么 D 在 <code>burst</code> 阶段的缓存命中率（87.7%）反而略低于 B2（90.8%）——
兜底把过载请求集中导向同一个"最闲"副本，使该副本上族混杂、局部性变差；
但 <code>steady</code> / <code>recovery</code> 阶段 D 显著优于 B2，整体命中率仍然更高。</p>

<h2>七、压测端未成为瓶颈</h2>
<p>五轮实验中客户端侧的排队与调度偏差都远小于服务端延迟，说明测量结果反映的是路由与服务行为，
而不是压测端自身的问题：</p>
<table>
<thead><tr><th style="width:46%">指标</th><th>五轮中的最大值（p99）</th></tr></thead>
<tbody>
<tr><td class="l"><code>client_queue_s</code></td><td>0.0006 s</td></tr>
<tr><td class="l"><code>dispatch_lag_s</code></td><td>0.0149 s</td></tr>
<tr><td class="l">对照：端到端延迟 p95</td><td>4.1 – 21.2 s</td></tr>
</tbody></table>

<h2>八、结论</h2>
<ol>
<li><b>路由策略在「缓存复用」与「负载均衡」之间存在真实张力</b>：A/B 偏均衡但缓存复用一般；
C 偏复用但热点后端过载、尾延迟崩坏；D 同时取得了两边的大部分收益。</li>
<li><b><code>max_ongoing_requests</code> 是入口并发容量，不是算力参数</b>：A 的 5 并发把全场限制在
20 个在飞请求，导致需要 46.5 s 才能跑完 29.5 s 的负载；调到 64 后几乎不积压，代价是 TPOT 上升 4.7 倍。</li>
<li><b>一致性哈希单独使用会把负载不均放大</b>：亲和性越强，"超热族"造成的偏斜越剧烈
（本例 1150 : 217 ≈ 5.3 倍）。因此在存在热点前缀族的负载上，路由器必须同时具备
<b>负载感知的兜底</b>与<b>完整的回退链</b>。</li>
<li>D 的实现只依赖当前请求与当前服务状态，代码可复现，分析与实测数据一致。</li>
</ol>

<h2>九、复现说明（一个必须记录的实验细节）</h2>
<p>Ray Serve 的请求路由器实例是<b>懒加载 + 永久缓存</b>的（<code>AsyncioRouter.request_router</code> 首次被访问时创建，
之后一直复用；<code>update_deployment_config()</code> 只更新"该用哪个路由器类"，<b>不会重建已有实例</b>）。
因此<b>在同一套代理进程下重新部署、仅更换路由器类是不生效的</b>——本次实验在最初执行 C 组时即撞上该问题，
表现为 C 的后端分布与 p2c 完全一致（539/516/512/481），缓存命中率也几乎未变。</p>
<p><b>处理办法</b>：每次切换路由器类别时，先 <code>ray stop --force</code> 重启整个 Ray 集群，再部署应用。
本报告中 C、D 两组数据均是在重启集群后采集的，并用"同一 <code>X-Session-Id</code> 连发 20 次是否落在同一后端"
做了前置验证（C 与 D 均为 20/20 命中同一后端）。</p>

{ganshou_html}

</body></html>
"""
    open(OUT, "w", encoding="utf-8").write(html)
    print("saved:", OUT, len(html), "chars")


if __name__ == "__main__":
    build()
