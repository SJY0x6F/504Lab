#!/bin/bash
# 一次性修补 pip 版 CUDA 工具链（让 flashinfer 能编译 kernel）
#
# 背景：镜像自带的 /usr/local/cuda 是 CUDA 11.8，而 sglang 依赖 torch cu130。
#       flashinfer 在启动时要用 nvcc JIT 编译 kernel，直接链接会失败：
#         /usr/bin/ld: cannot find -lcudart: No such file or directory
#         collect2: error: ld returned 1 exit status
#       pip 安装的 nvidia/cu13 少了开发用的软链接，本脚本把它补齐。
#
# 只需在环境装好后执行一次。
ENV=/root/autodl-tmp/env-sglang
SITE=$($ENV/bin/python -c "import site;print(site.getsitepackages()[0])")
CU13=$SITE/nvidia/cu13

echo "=== CU13 = $CU13 ==="
ls "$CU13/lib" | grep -E "cudart|cuda\.|nvrtc" || true

# ① flashinfer 传 -L$CUDA_HOME/lib64，但 pip 版只有 lib/
ln -sfn lib "$CU13/lib64"; echo "[1] lib64 -> lib"

# ② 补 libxxx.so 开发软链（实际只有 libxxx.so.13）
for f in "$CU13"/lib/lib*.so.*; do
  base=$(basename "$f"); short="${base%%.so.*}.so"
  [ -e "$CU13/lib/$short" ] || { ln -sf "$base" "$CU13/lib/$short"; echo "[2] $short -> $base"; }
done

# ③ libcuda.so（驱动库，-lcuda 需要）
mkdir -p "$CU13/lib/stubs"
STUB=""
for c in /usr/local/cuda/lib64/stubs/libcuda.so /usr/local/cuda-11.8/lib64/stubs/libcuda.so; do
  [ -e "$c" ] && STUB="$c" && break
done
[ -z "$STUB" ] && STUB=$(ldconfig -p 2>/dev/null | grep -m1 'libcuda\.so\.1' | awk '{print $NF}')
if [ -n "$STUB" ] && [ -e "$STUB" ]; then
  ln -sf "$STUB" "$CU13/lib/stubs/libcuda.so"; echo "[3] libcuda.so -> $STUB"
else
  echo "[3] !! 找不到 libcuda.so"
fi

# ④ CUDA 13 把 nv/target 挪进 CCCL
NVSRC="$SITE/flashinfer/data/cccl/libcudacxx/include/nv"
if [ -d "$NVSRC" ]; then
  rm -rf "$CU13/include/nv"; ln -sfn "$NVSRC" "$CU13/include/nv"
  echo "[4] include/nv -> $NVSRC"
else
  echo "[4] !! 找不到 $NVSRC"
fi
echo "=== 修补完成 ==="
