# -*- coding: utf-8 -*-
"""打印一轮实验的核心指标（报告主表用）。

用法：python show_headline.py <summary.json>
"""
import json
import sys

d = json.load(open(sys.argv[1], encoding="utf-8"))

print("run_name         :", d.get("run_name"))
print("router_name      :", d.get("router_name"))
print("max_ongoing_reqs :", d.get("max_ongoing_requests"),
      "| max_in_flight", d.get("max_in_flight"))
print("elapsed_s        :", d.get("elapsed_s"),
      "| throughput_rps", d.get("throughput_rps"))
print("offered_rate_rps :", d.get("offered_rate_rps"),
      "| planned_duration_s", d.get("planned_duration_s"))
print("cache_hit_rate   :", d.get("cache_hit_rate"))
print("prompt_tokens_total           :", d.get("prompt_tokens_total"))
print("cached_tokens_total           :", d.get("cached_tokens_total"))
print("computed_prefill_tokens_total :", d.get("computed_prefill_tokens_total"))
print()
for name in ("ttft_s", "tpot_s", "latency_s", "client_queue_s", "dispatch_lag_s"):
    v = d.get(name)
    if isinstance(v, dict):
        print(f"{name:16s}", {k: round(v[k], 4) for k in ("mean", "p50", "p95", "p99") if k in v})
print()
print("traffic_phases:")
for ph, v in (d.get("traffic_phases") or {}).items():
    print(" ", ph, "requests", v.get("requests"), "hit", v.get("cache_hit_rate"),
          "ttft_p95", (v.get("ttft_s") or {}).get("p95"))
