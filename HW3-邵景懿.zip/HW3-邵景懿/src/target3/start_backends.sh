#!/bin/bash
# 启动 4 个 SGLang 实例，各自独占一张 GPU（端口 30000–30003）
#
# 关键点：
#   · CUDA_HOME 指向 pip 装进环境里的 nvidia/cu13（系统自带的是 11.8，太旧）
#   · PATH 必须同时含「环境 bin」（ninja 在这里）与「CUDA bin」（nvcc 在这里）
#   · 镜像里 OMP_NUM_THREADS=0 是非法值，必须显式覆盖
ENV=/root/autodl-tmp/env-sglang
PY=$ENV/bin/python
SITE=$($PY -c "import site;print(site.getsitepackages()[0])")

if [ -d "$SITE/nvidia/cu13" ]; then
  export CUDA_HOME="$SITE/nvidia/cu13"
else
  echo "找不到 cu13，回退到系统 CUDA"; export CUDA_HOME=/usr/local/cuda
fi
export PATH="$ENV/bin:$CUDA_HOME/bin:$PATH"
export NVCC_PREPEND_FLAGS="-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK"
export MAX_JOBS=8

# 镜像里 OMP_NUM_THREADS=0 是非法值，必须显式覆盖
# 给 4 以给压测端留足 CPU（client_queue_s 不能成为瓶颈）
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4
export TOKENIZERS_PARALLELISM=false

MODEL=/root/autodl-tmp/models/Qwen3-0.6B
mkdir -p /root/autodl-tmp/logs

for i in 0 1 2 3; do
  CUDA_VISIBLE_DEVICES=$i nohup $PY -u -m sglang.launch_server \
    --model-path $MODEL --host 0.0.0.0 --port $((30000+i)) \
    --mem-fraction-static 0.85 --context-length 8192 \
    > /root/autodl-tmp/logs/sglang_$i.log 2>&1 &
  echo "后端 $i -> GPU $i, 端口 $((30000+i)), pid $!"
done
echo "已提交 4 个后端，首轮 JIT 编译约 3-5 分钟"
