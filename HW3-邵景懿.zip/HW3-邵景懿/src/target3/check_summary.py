# -*- coding: utf-8 -*-
"""按作业完成标准检查一轮 summary.json。

用法：python check_summary.py <summary.json>
"""
import json
import sys

KEYS = ["successful", "failed", "incomplete",
        "warmup_successful", "warmup_failed", "warmup_incomplete",
        "validation_errors", "replica_distribution",
        "node_distribution", "backend_distribution"]


def main():
    d = json.load(open(sys.argv[1], encoding="utf-8"))
    for k in KEYS:
        print(f"{k}: {d.get(k)}")
    print("--- 全部顶层键 ---")
    print(sorted(d.keys()))


if __name__ == "__main__":
    main()
