# 挑战三：比较并改进 Ray Serve 路由

本仓库包含挑战三（目标三）的完整实验材料：4 副本服务拓扑、四种路由配置的对照实验、
自定义路由器（D）的实现，以及目标一（前缀缓存对照实验）的代码与原始结果。

---

## 一、硬件与软件版本

| 项目 | 版本 / 配置 |
|---|---|
| GPU | 4 × NVIDIA RTX 4090 24GB（同一台服务器，AutoDL 实例） |
| CPU / 内存 | 64 vCPU / 480 GB |
| 操作系统 | Ubuntu 22.04（容器） |
| GPU 驱动 | 580.105.08（CUDA 13.0 兼容） |
| 模型 | Qwen/Qwen3-0.6B（bf16，权重约 1.18 GB） |
| 推理框架 | **SGLang 0.5.14** |
| 编排框架 | **Ray 2.56.0**（`ray[serve]`） |
| Python | 3.12（conda 环境建在数据盘：`/root/autodl-tmp/env-sglang`、`/root/autodl-tmp/env-ray`） |
| 关键依赖 | `torch 2.11.0+cu130`、`flashinfer`、`aiohttp 3.14.3`、**`protobuf 6.33.5`** |

> **`protobuf` 必须锁在 6.33.5**：Ray 2.56 的 Serve 代码使用了 protobuf 的 `FieldDescriptor.label`
> （7.x 已删除），而它的 `.proto` 生成代码又需要 `google.protobuf.runtime_version`
> （5.26 及更早没有）。实测只有 6.33.5 同时满足两者，否则会在部署时报
> `AttributeError: ... has no attribute 'label'` 或 `ImportError: cannot import name 'runtime_version'`。

---

## 二、安装方法

```bash
# 1) 建两个独立环境（建在数据盘，避免系统盘被依赖占满）
conda create -p /root/autodl-tmp/env-sglang python=3.12 -y
conda create -p /root/autodl-tmp/env-ray    python=3.12 -y

# 2) 装 SGLang（约 13–16 GB；用国内源）
/root/autodl-tmp/env-sglang/bin/pip install --no-cache-dir \
  -i https://pypi.tuna.tsinghua.edu.cn/simple sglang==0.5.14
/root/autodl-tmp/env-sglang/bin/pip install --no-cache-dir \
  -i https://pypi.tuna.tsinghua.edu.cn/simple "protobuf==6.33.5"

# 3) 装 Ray 与客户端依赖
/root/autodl-tmp/env-ray/bin/pip install --no-cache-dir \
  -i https://pypi.tuna.tsinghua.edu.cn/simple "ray[serve]==2.56.0" "aiohttp>=3.9,<4" "protobuf==6.33.5"

# 4) 下载模型（可选镜像加速）
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1          # hf-mirror 不支持 Xet 协议，必须关掉
/root/autodl-tmp/env-sglang/bin/hf download Qwen/Qwen3-0.6B \
  --local-dir /root/autodl-tmp/models/Qwen3-0.6B

# 5) 下载课程固定负载
source /etc/network_turbo            # AutoDL 学术加速
git clone https://github.com/Zirkland/26fall-HW-data.git /root/autodl-tmp/hwdata
cd /root/autodl-tmp/hwdata/workloads/hw2/target3-routing-policies
/root/autodl-tmp/env-ray/bin/pip install -r requirements.txt
/root/autodl-tmp/env-ray/bin/python validate_workload.py mooncake_prefix_workload_v2_seed2026.jsonl
# 期望：sha256 f154ba95…75b03 / families 64 / warmups 64 / measured 2048 / planned_duration_s 29.538768
```

### CUDA 工具链修补（必须执行一次）

镜像自带的 `/usr/local/cuda` 是 **CUDA 11.8**，而 sglang 需要 **CUDA 13**。
`src/target3/fix_cuda.sh` 会把 `CUDA_HOME` 指向 pip 装进环境里的 `nvidia/cu13`，并补齐它缺失的
开发用软链接（`libcudart.so` 等）、`libcuda.so` 与 CCCL 的 `nv/` 头文件目录。
**不修这一步行，启动 4 个后端时会报 `collect2: error: ld returned 1 exit status` / `cannot find -lcudart`。**

```bash
bash src/target3/fix_cuda.sh
```

---

## 三、启动与回放命令

### 1. 启动 4 个 SGLang 后端（每张卡一个）

```bash
bash src/target3/start_backends.sh
# 4 个实例分别在 30000 / 30001 / 30002 / 30003，各自 CUDA_VISIBLE_DEVICES=0..3
```

首轮启动要编译 flashinfer kernel（约 3–5 分钟）。完成后验证：

```bash
for p in 30000 30001 30002 30003; do
  echo -n "port $p -> "; curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:$p/health
done
nvidia-smi --query-gpu=index,memory.used --format=csv
```

### 2. 启动 Ray 集群（1 head + 4 逻辑 worker）

```bash
nohup /root/autodl-tmp/env-ray/bin/python -u src/target3/ray_cluster.py \
  > /root/autodl-tmp/logs/ray_cluster.log 2>&1 &
sleep 25 && tail -12 /root/autodl-tmp/logs/ray_cluster.log   # 期望「节点总数: 5」
```

`ray_cluster.py` 会用 `ray.cluster_utils.Cluster` 建 1 个 head（8 CPU）与 4 个 worker（各 4 CPU），
并给**每个 worker 打同一个自定义资源标签** `sglang_worker`，把节点 ID 写入
`/root/autodl-tmp/ray_meta/nodes.json` 供 Replica 反查自己的后端序号。

### 3. 部署 Ray Serve 应用（选择路由器配置）

```bash
cd /root/autodl-tmp && PYTHONPATH=/root/autodl-tmp nohup \
  /root/autodl-tmp/env-ray/bin/python -u src/target3/serve_app.py \
  --router <p2c|consistent_hash|d_custom> \
  --max-ongoing-requests <N> \
  > /root/autodl-tmp/logs/serve_app.log 2>&1 &
sleep 30 && grep -i "ready at\|initialized\|Traceback" /root/autodl-tmp/logs/serve_app.log | tail -3
```

对应四组实验的部署命令：

| 组 | 部署参数 |
|---|---|
| A | `--router p2c --max-ongoing-requests 5` |
| B 候选 1 | `--router p2c --max-ongoing-requests 32` |
| B 候选 2（**选定**） | `--router p2c --max-ongoing-requests 64` |
| C | `--router consistent_hash --max-ongoing-requests 64 --num-fallback-replicas 0 --num-virtual-nodes 100` |
| D | `--router d_custom --max-ongoing-requests 64 --num-virtual-nodes 100 --overflow-ratio 1.5 --overflow-slack 2` |

> ⚠️ **切换路由器类别时必须先重启 Ray 集群**，否则新路由器不会生效。
> 原因见文末「注意事项」。

### 4. 回放固定负载

每轮流程：**重新部署 Serve → 清空 4 个后端缓存 → 回放负载**。

```bash
# ① 清空四个 SGLang 后端的 RadixCache（必须四个都返回 200）
for p in 30000 30001 30002 30003; do
  echo -n "port $p flush -> "
  curl -s -o /dev/null -w "%{http_code}\n" -X POST http://127.0.0.1:$p/flush_cache
done

# ② 回放（在负载目录下执行）
cd /root/autodl-tmp/hwdata/workloads/hw2/target3-routing-policies
nohup /root/autodl-tmp/env-ray/bin/python -u run_workload.py \
  --policy serve \
  --run-name A_default_run1 \
  --router-name p2c \
  --max-ongoing-requests 5 \
  --base-url http://127.0.0.1:8000 \
  --workload mooncake_prefix_workload_v2_seed2026.jsonl \
  --max-in-flight 2048 \
  --output-dir <结果目录> \
  > /root/autodl-tmp/logs/run_A.log 2>&1 &
```

### 5. 汇总与校验

```bash
# 单轮判定（本仓库附带的小工具）
/root/autodl-tmp/env-ray/bin/python src/target3/check_summary.py <summary.json>
# 关键指标速览
/root/autodl-tmp/env-ray/bin/python src/target3/show_headline.py <summary.json>

# 四组横向汇总（课程自带）
cd /root/autodl-tmp/hwdata/workloads/hw2/target3-routing-policies
/root/autodl-tmp/env-ray/bin/python compare_runs.py --baseline A \
  --run A=.../A_default/summary.json \
  --run B1=.../B_candidates/candidate-1/summary.json \
  --run B2=.../B_candidates/candidate-2/summary.json \
  --run C=.../C_affinity/summary.json \
  --run D=.../D_improved/summary.json \
  --output results/target3/comparison.json
```

---

## 四、脚本用途

### `src/target3/`（目标三：四副本路由）

| 文件 | 用途 |
|---|---|
| `start_backends.sh` | 启动 4 个 SGLang 实例（各占一张 GPU，端口 30000–30003），含 CUDA_HOME / PATH / MAX_JOBS 与 OMP 线程数设置 |
| `fix_cuda.sh` | 一次性 CUDA 工具链修补（pip 版 cu13 的软链接、stubs、CCCL 头文件） |
| `ray_cluster.py` | 用 `ray.cluster_utils.Cluster` 建 1 head + 4 worker，打 `sglang_worker` 资源标签，导出 `nodes.json` |
| `serve_app.py` | **Ray Serve Deployment**：4 个 Replica 钉在 4 个 worker 上，按节点身份固定转发到一个 SGLang 后端，原样转发 SSE 并注入 `X-Ray-*` 响应头；通过 `--router` 切换 p2c / consistent_hash / d_custom |
| `affinity_router.py` | **D 的路由代码**：`AffinityAwareRouter`，继承 Ray 的 `ConsistentHashRouter`，重写 `choose_replicas`，实现「前缀亲和 + 队列深度兜底」 |
| `check_summary.py` | 按作业完成标准检查一轮 `summary.json`（2048/0/0、warmup、validation_errors、四项分布） |
| `show_headline.py` | 打印一轮的核心指标（吞吐、命中率、Prefill、TTFT/TPOT/延迟分位、分阶段） |
| `cdf_dump.py` | 从各组 `requests.csv` 导出 TTFT / 延迟百分位，供绘制 CDF 图 |
| `requirements.txt` | 依赖版本清单 |
| `report/` | 报告与图表的生成脚本、图片源文件（`build_report_hw3.py` 生成 `report.html`，再用无头 Edge 转 PDF） |

### `src/target1/`（目标一：前缀缓存对照实验）

| 文件 | 用途 |
|---|---|
| `run_experiment.py` | 对照实验主体：共享前缀组 vs 分散前缀组，各 32 条请求，记录逐请求指标 |
| `run_fg.sh` / `start_server.sh` | 启动 SGLang 服务（前台阻塞运行，避免 WSL 空闲回收） |
| `check2.py` / `check_service.py` | 服务健康检查 |
| `probe_api.py` | 探测 `/generate`、`/flush_cache` 的真实返回格式 |
| `make_table_image.py` | 把 `comparison.json` 渲染成对照表图片 |

---

## 五、结果目录与报告表格的对应关系

```
results/
├── target1/
│   ├── comparison.json            目标一：两组汇总
│   ├── comparison_table.png       目标一：对照表（报告用图）
│   ├── shared_prefix/             共享前缀组（32 条请求的逐请求结果 + 汇总）
│   └── dispersed_prefix/          分散前缀组
└── target3/
    ├── A_default/                 组 A：p2c，max_ongoing_requests=5
    ├── B_candidates/
    │   ├── candidate-1/           组 B 候选 1：p2c，max_ongoing_requests=32
    │   └── candidate-2/           组 B 候选 2：p2c，max_ongoing_requests=64（选定）
    ├── C_affinity/                组 C：ConsistentHashRouter，num_fallback_replicas=0
    └── D_improved/                组 D：AffinityAwareRouter（自定义）
```

每个 `results/target3/<组>/` 目录内含流量发生器生成的四个文件：

| 文件 | 内容 |
|---|---|
| `config.json` | 命令行、模型、路由器、并发参数、负载 SHA-256、校验状态 |
| `warmups.csv` | 64 条预热请求的逐请求结果 |
| `requests.csv` | 2048 条测量请求的逐请求结果（`ttft_s`、`tpot_s`、`latency_s`、`cached_tokens`、`replica_id`、`ray_node_id`、`backend`、`dispatch_lag_s`、`client_queue_s` 等） |
| `summary.json` | 全程 / 各阶段 / 各热度层级的汇总指标 |

### 报告表格与原始结果的对应

| 报告中的位置 | 数据来源 |
|---|---|
| 表 1「组别 / 配置」列 | 各组 `config.json` 的 `router_name`、`max_ongoing_requests` |
| 表 1「成功率」 | `summary.json` → `successful` / `failed` / `incomplete` |
| 表 1「吞吐量 (req/s)」 | `summary.json` → `throughput_rps` |
| 表 1「缓存命中率」 | `summary.json` → `cache_hit_rate`（= `cached_tokens_total` / `prompt_tokens_total`） |
| 表 1「实际 Prefill token 数」 | `summary.json` → `computed_prefill_tokens_total` |
| 表 1「TTFT p95」「端到端 p95」 | `summary.json` → `ttft_s.p95`、`latency_s.p95` |
| 表 1「四个后端请求分布」 | `summary.json` → `backend_distribution`（键为 `backend-0`…`backend-3`） |
| 图 2（CDF 曲线） | 各组 `requests.csv` 的 `ttft_s` 列与 `latency_s` 列，按百分位绘制 |
| 图 1（流程图） | 服务实现本身（`serve_app.py` + `affinity_router.py`） |
| 报告中「client_queue / dispatch_lag 未成瓶颈」 | `summary.json` → `client_queue_s.p99`、`dispatch_lag_s.p99` |
| 报告中分阶段（steady / burst / recovery）结论 | `summary.json` → `traffic_phases` |
| 报告中「D 的兜底触发率 7.2%」 | Ray 服务日志中 `AffinityAwareRouter: N routes, M overflowed (x%)` |

---

## 六、注意事项

1. **切换路由器类别必须重启 Ray 集群。**
   Ray Serve 的请求路由器实例是「懒加载 + 永久缓存」的：`AsyncioRouter.request_router` 在首次被访问时
   创建实例，之后一直复用；`update_deployment_config()` 只更新「该用哪个路由器类」，**不会重建已有实例**。
   因此，若只是在同一套代理进程下重新部署并改 `request_router_config`，**新路由器不会生效**
   （表现为 C 组的后端分布与 p2c 完全一致）。做法是：`ray stop --force` → 重启 `ray_cluster.py` → 再部署。
   切换后可先用「同一 `X-Session-Id` 连发 20 次是否落在同一后端」验证亲和性已生效。

2. **protobuf 必须锁在 6.33.5**（原因见第一节）。

3. **每张卡只跑一个实例**，`--mem-fraction-static 0.85`；4 个实例的启动参数必须完全一致。

4. **每轮实验前必须清空 4 个后端的 RadixCache**，否则会带上上一轮的缓存残留，结果不可比。

5. 报告中的数据均可在 `results/` 中逐条对应到原始结果；B 组记录了两次候选实验，
   其余配置各一轮。
