# HW2 — SGLang 前缀缓存测量与请求流程阅读

504 实验室招新考核 · 第二次挑战
姓名：邵景懿

---

## 一、硬件与软件版本

| 项目 | 版本 / 型号 |
|---|---|
| GPU | NVIDIA GeForce RTX 5070 Laptop GPU（8 GB 显存） |
| 显卡驱动 | 591.91 |
| CUDA（驱动支持） | 13.1 |
| 操作系统 | Windows 11 + WSL2（Ubuntu 24.04） |
| Python | 3.12 |
| SGLang | 0.5.14 |
| PyTorch | 2.11.0+cu130 |
| Transformers | 5.8.1 |
| Ray | 2.56.0 |
| 模型 | Qwen/Qwen3-0.6B |

> 说明：`sglang 0.5.14` 官方只提供 Linux（manylinux）轮子，没有 Windows 版，
> 因此全部实验在 **WSL2（Ubuntu 24.04）** 内完成。

---

## 二、安装方法

### 1. 建立两个环境

SGLang 与 Ray 分开两个 conda 环境（SGLang 会把 torch / transformers
版本钉死，混装会冲突）。两者通过 HTTP 通信。

```bash
conda create -n env-sglang python=3.12 -y
conda activate env-sglang
pip install sglang==0.5.14 -i https://pypi.tuna.tsinghua.edu.cn/simple

conda create -n env-ray python=3.12 -y
conda activate env-ray
pip install ray==2.56.0 -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 2. 下载模型

```bash
pip install "huggingface_hub[cli]"
HF_ENDPOINT=https://hf-mirror.com \
  hf download Qwen/Qwen3-0.6B --local-dir ~/models/Qwen3-0.6B
```

### 3. CUDA 工具链修补（pip 版 CUDA 必需）

服务器启动时 flashinfer 要现场 JIT 编译 kernel，而 pip 安装的 CUDA
目录结构与标准安装不同，需要做以下修补（已固化在 `src/target1/run_fg.sh`）：

1. `CUDA_HOME` 指向 `site-packages/nvidia/cu13`
2. `NVCC_PREPEND_FLAGS=-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK`
   （nvcc 与 CCCL 头文件次版本不一致，跳过该检查）
3. 补 `lib64/stubs` 与 `include/nv` 软链接
4. `MAX_JOBS=2`（限制 JIT 并发，防止内存被打爆）
5. **PATH 同时包含 conda 环境 bin 与 CUDA bin**
   （`ninja` 只装在环境里，系统没有；缺了会报
   `FileNotFoundError: 'ninja'`）

---

## 三、启动与回放命令

> ⚠️ 在 WSL 里启动长驻服务必须**前台阻塞运行**。
> 若用 `nohup ... &` / `setsid ... &` 脱离终端启动，`wsl.exe` 返回后
> WSL 会话结束，虚拟机空闲超时会把服务一起杀掉（现象是日志莫名断在某一行）。

```bash
# ① 启动服务（前台阻塞，保持窗口不关）
bash src/target1/run_fg.sh
#    约 30 秒后出现 "The server is fired up and ready to roll!" 即成功

# ② 另开一个 WSL 终端，确认服务就绪
python src/target1/check2.py
#    预期输出 HEALTH: 200 与模型信息

# ③ 任务一：两组对照实验（顺序执行）
python src/target1/run_experiment.py --group both
#    约 10 秒跑完，结果写入 results/target1/

# ④ 生成对照表图片（可选，需要 pillow）
python src/target1/make_table_image.py --results results/target1
```

---

## 四、脚本用途

| 脚本 | 用途 |
|---|---|
| `src/target1/run_fg.sh` | **启动服务**（前台阻塞，含全部 CUDA 修补与工具自检） |
| `src/target1/start_server.sh` | 启动服务的等价写法 |
| `src/target1/check2.py` | 检查 `/health` 与 `/v1/models` 是否就绪 |
| `src/target1/check_service.py` | 同上，输出更简 |
| `src/target1/run_experiment.py` | **任务一核心**：两组对照实验 + 指标统计 |
| `src/target1/probe_api.py` | 探测接口真实返回格式（排错用） |
| `src/target1/make_table_image.py` | 把 `comparison.json` 渲染成对照表图片 |

---

## 五、结果目录与报告表格的对应关系

```
results/
└── target1/
    ├── comparison.json           → 报告「任务一 对照表」两组合并的原始数值
    ├── comparison_table.png      → 报告「任务一 对照表」图片
    ├── shared_prefix/
    │   ├── per_request.csv       → 报告附表：共享前缀组 32 条逐请求明细
    │   └── summary.json          → 报告「任务一 对照表」共享前缀组那一列
    └── dispersed_prefix/
        ├── per_request.csv       → 报告附表：分散前缀组 32 条逐请求明细
        └── summary.json          → 报告「任务一 对照表」分散前缀组那一列
```

报告正文 / 表格中的每一个数字，都可以在上述 JSON 或 CSV 中找到原始值。
`per_request.csv` 的列含义：

| 列 | 含义 |
|---|---|
| `req_id` | 请求序号（0–31） |
| `prompt_tokens` | 输入 token 数 |
| `completion_tokens` | 输出 token 数 |
| `cached_tokens` | 命中缓存的 token 数（取自 `meta_info.cached_tokens`） |
| `prefill_tokens` | 实际执行 Prefill 的 token 数 = `prompt_tokens − cached_tokens` |
| `ttft_ms` | 首 token 延迟 |
| `tpot_ms` | 每输出 token 耗时 |
| `e2e_ms` | 端到端延迟 |
| `status` / `error` | 成功与否及错误信息 |

---

## 六、任务一实验设计

**两组唯一差别 = 前缀能否复用**，其余全部保持一致。

| 负载 | 输入结构 | 测量前准备 |
|---|---|---|
| 共享前缀组 | 2048 个 token 的共享前缀 + 64 个 token 的独立后缀（总长 2112） | 发送 1 条包含共享前缀的预热请求 |
| 分散前缀组 | 输入长度均为 2112 个 token，且**首个 token 各不相同** | 不进行前缀预热 |

- 接口：原生 `/generate`，传 `input_ids`，**流式响应**
- 统一参数：`temperature=0`、`max_new_tokens=16`、`ignore_eos=true`、
  `sampling_seed=2026`
- 每组 32 条测量请求，最大并发 8
- 流程：服务预热 → 每组前等待空闲 → `POST /flush_cache` 并确认成功 →
  （共享前缀组额外发送 1 条预热请求，不计入结果）→ 发送 32 条测量请求

**指标定义**：

```
缓存命中率         = sum(cached_tokens) / sum(prompt_tokens)
实际 Prefill token = sum(prompt_tokens − cached_tokens)
```

---

## 七、任务二说明

任务二为源码阅读，无独立代码文件。产出的流程图见 `report.pdf`。
关键函数所在文件与行号（`sglang 0.5.14`，源码根 `sglang/srt/`）：

| 步骤 | 关键函数 | 文件 : 行号 |
|---|---|---|
| ① 接收请求、tokenize | `TokenizerManager.generate_request` | `managers/tokenizer_manager.py : 576` |
| ①' 发往 Scheduler | `TokenizerManager._send_one_request` | `managers/tokenizer_manager.py : 1319` |
| ② 调度循环收请求 | `Scheduler.process_input_requests` | `managers/scheduler.py : 1628` |
| ②' 请求入队 | `Scheduler._add_request_to_queue` | `managers/scheduler.py : 2258` |
| ②'' 等待队列入队 | `self.waiting_queue.append(req)` | `managers/scheduler.py : 2265` |
| ③ 调度主循环 | `Scheduler.event_loop_normal` | `managers/scheduler.py : 1505` |
| ③' 取 prefill 批 | `Scheduler.get_new_batch_prefill` | `managers/scheduler.py : 2702` |
| ④ 前缀匹配（策略侧） | `match_prefix_for_req` | `managers/schedule_policy.py : 85` |
| ④' 前缀匹配（树侧） | `RadixCache.match_prefix` | `mem_cache/radix_cache.py : 358` |
| ⑤ 组批与 prefill 预算 | `class PrefillAdder` | `managers/schedule_policy.py : 425` |
| ⑤' 批对象 | `class ScheduleBatch` | `managers/schedule_batch.py : 1671` |
| ⑥ 执行 | `Scheduler.run_batch` | `managers/scheduler.py : 3145` |
| ⑥' 处理结果 | `Scheduler.process_batch_result` | `managers/scheduler.py : 3367` |
| ⑦ KV 写回（请求结束） | `release_kv_cache` → `cache_finished_req` | `mem_cache/common.py : 629` → `radix_cache.py : 438` |
| ⑦' KV 写回（未结束） | `maybe_cache_unfinished_req` → `cache_unfinished_req` | `mem_cache/common.py : 113` → `radix_cache.py : 485` |
| ⑧ 流式输出组装 | `TokenizerManager._handle_batch_output` | `managers/tokenizer_manager.py : 1839` |
| ⑧' 逐块 yield | `TokenizerManager._wait_one_response` | `managers/tokenizer_manager.py : 1425` |
