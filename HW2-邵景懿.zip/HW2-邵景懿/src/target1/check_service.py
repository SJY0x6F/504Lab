#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""检查 SGLang 服务是否就绪"""
import sys
import urllib.request
import json

BASE = "http://127.0.0.1:30000"


def check(path, desc):
    try:
        with urllib.request.urlopen(BASE + path, timeout=10) as r:
            body = r.read().decode()
            print(f"[OK]   {desc:<20} {path}  ->  {body[:200]}")
            return True
    except Exception as e:
        print(f"[FAIL] {desc:<20} {path}  ->  {e}")
        return False


if __name__ == "__main__":
    ok = True
    ok &= check("/health", "健康检查")
    ok &= check("/v1/models", "模型列表")
    if ok:
        print("\n服务已就绪，可以开始实验。")
    else:
        print("\n服务未就绪，请先启动服务。")
        sys.exit(1)
