import json
import urllib.request

# 1) 测 flush_cache 的真实返回
req = urllib.request.Request("http://127.0.0.1:30000/flush_cache", method="POST")
with urllib.request.urlopen(req, timeout=30) as r:
    print("flush status:", r.status)
    print("flush content-type:", r.headers.get("Content-Type"))
    print("flush body:", repr(r.read().decode()))

# 2) 测 /generate 流式返回格式
payload = {
    "input_ids": list(range(1000, 1064)),
    "stream": True,
    "sampling_params": {
        "temperature": 0.0,
        "max_new_tokens": 4,
        "ignore_eos": True,
        "sampling_seed": 2026,
    },
}
req = urllib.request.Request(
    "http://127.0.0.1:30000/generate",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json"},
    method="POST",
)
print("\n--- generate stream chunks ---")
n = 0
with urllib.request.urlopen(req, timeout=60) as r:
    print("status:", r.status, "ct:", r.headers.get("Content-Type"))
    for raw in r:
        line = raw.decode("utf-8", errors="ignore").strip()
        if not line:
            continue
        n += 1
        print(f"[chunk {n}] {line[:400]}")
        if n >= 8:
            print("... (truncated)")
            break
