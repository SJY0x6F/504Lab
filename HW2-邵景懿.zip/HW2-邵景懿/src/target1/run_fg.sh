#!/bin/bash
# 前台阻塞运行 SGLang 服务，保持 WSL 会话活跃（避免 VM 空闲超时被杀）
# 用法: bash run_fg.sh

ENV=~/miniconda3/envs/env-sglang
PY="$ENV/bin/python"

if [ ! -x "$PY" ]; then
  echo "找不到 $PY —— 请确认 env-sglang 环境存在"
  exit 1
fi

SITE=$("$PY" -c "import site;print(site.getsitepackages()[0])")
export CUDA_HOME="$SITE/nvidia/cu13"

# ⚠️ 关键：PATH 必须同时包含 ①conda 环境的 bin ②CUDA 的 bin
#   ① 提供 ninja —— flashinfer 的 JIT 编译必需，系统里没装
#   ② 提供 nvcc
export PATH="$ENV/bin:$CUDA_HOME/bin:$PATH"

# 跳过 nvcc 与 CCCL 头文件的版本一致性检查
export NVCC_PREPEND_FLAGS="-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK"
# 限制 JIT 编译并发，防止内存被打爆导致 WSL 虚拟机崩溃
export MAX_JOBS=2

# 启动前自检：缺工具就早报错，别等到服务启动一半才崩
for tool in ninja nvcc; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "❌ 找不到 $tool，服务无法启动。"
    exit 1
  fi
done
echo "ninja = $(command -v ninja)"
echo "nvcc  = $(command -v nvcc)"
echo "[$(date +%H:%M:%S)] === 启动服务（前台阻塞，请勿关闭此窗口） ==="

exec "$PY" -u -m sglang.launch_server \
  --model-path ~/models/Qwen3-0.6B \
  --host 0.0.0.0 --port 30000 \
  --mem-fraction-static 0.6 \
  --context-length 8192 \
  --log-level info "$@"
