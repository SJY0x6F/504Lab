import urllib.request, json, sys
try:
    r = urllib.request.urlopen("http://127.0.0.1:30000/health", timeout=10)
    print("HEALTH:", r.status, r.read().decode()[:200])
except Exception as e:
    print("HEALTH FAIL:", repr(e))

try:
    r = urllib.request.urlopen("http://127.0.0.1:30000/v1/models", timeout=10)
    d = json.loads(r.read().decode())
    print("MODELS:", json.dumps(d)[:300])
except Exception as e:
    print("MODELS FAIL:", repr(e))
