#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HW2 任务一：测量 SGLang 前缀缓存效果
=====================================================

实验设计（两组唯一差别 = 前缀能否复用）
------------------------------------------------------
* shared_prefix  组：32 条请求共享同一段长前缀（+各自不同的短后缀）
                     → 第一条请求 prefill 并写入 RadixCache，
                       后续请求可以命中前缀，实际 prefill token 大幅减少
* dispersed_prefix 组：32 条请求前缀各不相同
                     → 无法复用，每条都要完整 prefill

统一参数
------------------------------------------------------
  temperature=0, max_new_tokens=16, ignore_eos=True, sampling_seed=2026
  每组 32 条请求，最大并发 8，流式响应，原生 /generate 接口

流程（严格遵守作业要求）
------------------------------------------------------
  1. 服务预热（短请求）
  2. 每组实验前：等待在途请求结束 -> POST /flush_cache -> 确认 success
  3. 【共享前缀组】flush 之后再发送"预热请求"(warmup)，写满前缀
       - 预热请求不计入结果
  4. 发送 32 条测量请求（并发上限 8），逐条记录指标
  5. 汇总统计

记录指标
------------------------------------------------------
  成功率 / 吞吐量 / 缓存命中率 / 实际 prefill token 数
  TTFT, TPOT, 端到端延迟 的 p50 / p95

用法（WSL 中）:  python run_experiment.py --group shared
                 python run_experiment.py --group dispersed
                 python run_experiment.py --group both
"""

import argparse
import asyncio
import csv
import json
import os
import statistics
import sys
import time
from dataclasses import dataclass, field, asdict
from typing import List, Optional

import aiohttp

# ============================================================
# 全局配置
# ============================================================
BASE_URL = "http://127.0.0.1:30000"

N_REQUESTS = 32          # 每组测量请求数
MAX_CONCURRENCY = 8      # 最大并发数
MAX_NEW_TOKENS = 16      # 统一输出长度
SAMPLING_SEED = 2026     # 统一随机种子

# 长度一致性控制（严格按作业表格）
#   共享前缀组：2048 个 token 的共享前缀 + 64 个 token 的独立后缀
#   分散前缀组：总长同样 2112 个 token，但首个 token 各不相同（首个 token
#               就分叉 -> 任意两条请求的公共前缀长度为 0，无法复用）
PREFIX_LEN = 2048        # 共享前缀长度（token）
SUFFIX_LEN = 64          # 每条请求专属后缀长度（token）
TOTAL_LEN = PREFIX_LEN + SUFFIX_LEN   # = 2112，两组必须一致

RESULT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")

# ============================================================
# 数据模型
# ============================================================


@dataclass
class ReqResult:
    """单条请求的测量结果"""
    req_id: int
    prompt_tokens: int = 0        # 输入 token 数
    completion_tokens: int = 0    # 输出 token 数
    cached_tokens: int = 0        # 命中缓存的 token 数
    prefill_tokens: int = 0       # 实际执行 prefill 的 token 数
    ttft_ms: float = -1.0         # 首 token 延迟
    tpot_ms: float = -1.0         # 每输出 token 耗时
    e2e_ms: float = -1.0          # 端到端延迟
    status: str = "pending"       # success / error
    error: str = ""
    start_ts: float = 0.0
    end_ts: float = 0.0


# ============================================================
# 工具函数
# ============================================================


async def flush_cache(session: aiohttp.ClientSession) -> bool:
    """
    清空 RadixCache。

    注意：/flush_cache 返回的是**纯文本**（不是 JSON）：
      成功 -> HTTP 200 + "Cache flushed. ..."
      失败 -> HTTP 400
    且服务端明确提示：当有正在运行或等待的请求时，该操作不会被执行。
    因此以 HTTP 状态码判定成功与否。
    """
    async with session.post(f"{BASE_URL}/flush_cache") as resp:
        body = (await resp.text()).strip()
        ok = resp.status == 200
        print(f"  [flush_cache] status={resp.status} ok={ok} body={body[:80]!r}")
        return ok


async def wait_idle(session: aiohttp.ClientSession, timeout: float = 30.0):
    """等待在途请求结束（轮询 /health 确认服务空闲）"""
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            async with session.get(f"{BASE_URL}/health") as resp:
                if resp.status == 200:
                    await asyncio.sleep(0.5)
                    return
        except Exception:
            pass
        await asyncio.sleep(0.3)
    print("  [wait_idle] 等待超时，继续")


def build_prefix_tokens(prefix_id: int, length: int) -> List[int]:
    """
    生成固定长度的 token 序列。
    用确定性的伪随机，保证可复现；不同 prefix_id 产生不同序列。
    """
    import random
    rng = random.Random(10000 + prefix_id)
    # 使用常见 token 区间，避免特殊 token
    return [rng.randrange(1000, 20000) for _ in range(length)]


def build_prompts(group: str) -> List[List[int]]:
    """
    按作业表格构造两组 prompt（总长均 = 2112 token）。

    shared   : 前 2048 个 token 完全相同（共享前缀），后 64 个 token 各自不同。
               配合「测量前发送 1 条含共享前缀的预热请求」，32 条测量请求
               都应命中这 2048 个 token 的前缀。
    dispersed: 每条请求的首个 token 就不同，因此任意两条的公共前缀长度为 0，
               完全不进行前缀预热 -> 无缓存复用。
    """
    prompts = []
    for i in range(N_REQUESTS):
        suffix = build_prefix_tokens(999 + i, SUFFIX_LEN)   # 64 token，各自不同
        if group == "shared":
            prefix = build_prefix_tokens(0, PREFIX_LEN)     # 2048 token，全部相同
        else:
            # 分散前缀：首个 token 各不相同 -> 从位置 0 就分叉
            prefix = [3000 + i] + build_prefix_tokens(i + 1, PREFIX_LEN - 1)
        prompts.append(prefix + suffix)
    assert all(len(p) == TOTAL_LEN for p in prompts), "两组长度必须一致"
    return prompts


# ============================================================
# 单条请求：流式发送，测量 TTFT / TPOT
# ============================================================


async def send_one(
    session: aiohttp.ClientSession,
    sem: asyncio.Semaphore,
    req_id: int,
    input_ids: List[int],
) -> ReqResult:
    """发送一条流式请求，返回测量结果"""
    res = ReqResult(req_id=req_id)
    payload = {
        "input_ids": input_ids,
        "stream": True,
        "sampling_params": {
            "temperature": 0.0,
            "max_new_tokens": MAX_NEW_TOKENS,
            "ignore_eos": True,
            "sampling_seed": SAMPLING_SEED,
        },
        # 让返回里带上 prompt/cached token 统计
        "return_logprob": False,
    }

    async with sem:  # 控制并发数
        res.start_ts = time.time()
        try:
            async with session.post(f"{BASE_URL}/generate", json=payload) as resp:
                if resp.status != 200:
                    res.status = "error"
                    res.error = f"HTTP {resp.status}: {await resp.text()}"
                    res.end_ts = time.time()
                    res.e2e_ms = (res.end_ts - res.start_ts) * 1000
                    return res

                first_token_ts: Optional[float] = None
                last_token_ts: Optional[float] = None
                n_tokens = 0
                meta = {}

                # 解析 SSE 流
                async for raw in resp.content:
                    line = raw.decode("utf-8", errors="ignore").strip()
                    if not line or not line.startswith("data:"):
                        continue
                    data_str = line[len("data:"):].strip()
                    if data_str == "[DONE]":
                        break
                    try:
                        obj = json.loads(data_str)
                    except Exception:
                        continue

                    now = time.time()
                    if first_token_ts is None:
                        first_token_ts = now
                    last_token_ts = now
                    n_tokens += 1

                    # 最后一个 chunk 里含 meta_info
                    if "meta_info" in obj:
                        meta = obj["meta_info"]

                res.end_ts = time.time()
                res.e2e_ms = (res.end_ts - res.start_ts) * 1000

                # --- 指标计算 ---
                if first_token_ts is not None:
                    res.ttft_ms = (first_token_ts - res.start_ts) * 1000
                    # TPOT：从首 token 到最后一个 token 的平均每 token 耗时
                    if n_tokens > 1:
                        res.tpot_ms = (last_token_ts - first_token_ts) * 1000 / (n_tokens - 1)

                res.prompt_tokens = meta.get("prompt_tokens", len(input_ids))
                res.completion_tokens = meta.get("completion_tokens", n_tokens)
                res.cached_tokens = meta.get("cached_tokens", 0)
                res.prefill_tokens = max(0, res.prompt_tokens - res.cached_tokens)
                res.status = "success" if n_tokens > 0 else "error"
                if n_tokens == 0:
                    res.error = "no token received"

        except Exception as e:
            res.status = "error"
            res.error = repr(e)
            res.end_ts = time.time()
            res.e2e_ms = (res.end_ts - res.start_ts) * 1000

    return res


# ============================================================
# 汇总统计
# ============================================================


def pct(values: List[float], p: float) -> float:
    """百分位数（线性插值）"""
    if not values:
        return -1.0
    vs = sorted(values)
    if len(vs) == 1:
        return vs[0]
    k = (len(vs) - 1) * p
    f = int(k)
    c = min(f + 1, len(vs) - 1)
    if f == c:
        return vs[f]
    return vs[f] + (vs[c] - vs[f]) * (k - f)


def summarize(group: str, results: List[ReqResult]) -> dict:
    ok = [r for r in results if r.status == "success"]
    n = len(results)
    n_ok = len(ok)

    total_out = sum(r.completion_tokens for r in ok)
    total_prompt = sum(r.prompt_tokens for r in ok)
    total_cached = sum(r.cached_tokens for r in ok)
    total_prefill = sum(r.prefill_tokens for r in ok)

    # 墙钟吞吐（从最早开始到最晚结束）
    if results:
        t0 = min(r.start_ts for r in results)
        t1 = max(r.end_ts for r in results)
        wall = max(t1 - t0, 1e-6)
    else:
        wall = 1e-6

    ttfts = [r.ttft_ms for r in ok if r.ttft_ms >= 0]
    tpots = [r.tpot_ms for r in ok if r.tpot_ms >= 0]
    e2es = [r.e2e_ms for r in ok if r.e2e_ms >= 0]

    s = {
        "group": group,
        "n_requests": n,
        "n_success": n_ok,
        "success_rate": round(n_ok / n * 100, 2) if n else 0.0,
        # 长度一致性校验
        "prompt_tokens_each": sorted(set(r.prompt_tokens for r in ok)),
        "completion_tokens_each": sorted(set(r.completion_tokens for r in ok)),
        # 缓存
        "total_prompt_tokens": total_prompt,
        "total_cached_tokens": total_cached,
        "total_prefill_tokens": total_prefill,
        "cache_hit_rate": round(total_cached / total_prompt * 100, 2) if total_prompt else 0.0,
        "avg_prefill_tokens": round(total_prefill / n_ok, 1) if n_ok else 0.0,
        # 吞吐
        "wall_time_s": round(wall, 3),
        "request_throughput_rps": round(n_ok / wall, 3),
        "output_throughput_tok_per_s": round(total_out / wall, 2),
        # 延迟
        "ttft_p50_ms": round(pct(ttfts, 0.50), 2),
        "ttft_p95_ms": round(pct(ttfts, 0.95), 2),
        "tpot_p50_ms": round(pct(tpots, 0.50), 3),
        "tpot_p95_ms": round(pct(tpots, 0.95), 3),
        "e2e_p50_ms": round(pct(e2es, 0.50), 2),
        "e2e_p95_ms": round(pct(e2es, 0.95), 2),
    }
    return s


# ============================================================
# 单组实验主流程
# ============================================================


async def run_group(group: str) -> dict:
    out_dir = os.path.abspath(os.path.join(RESULT_DIR, group))
    os.makedirs(out_dir, exist_ok=True)

    print(f"\n{'='*64}")
    print(f"  实验组: {group}")
    print(f"{'='*64}")

    conn = aiohttp.TCPConnector(limit=MAX_CONCURRENCY * 2)
    timeout = aiohttp.ClientTimeout(total=600)
    async with aiohttp.ClientSession(connector=conn, timeout=timeout) as session:

        # --- 1. 等待在途请求结束 ---
        await wait_idle(session)

        # --- 2. 清空缓存 ---
        print("[流程] flush_cache ...")
        if not await flush_cache(session):
            print("  !! flush_cache 失败，仍然继续")

        # --- 3. 共享前缀组：发送 1 条含共享前缀的预热请求（不计入结果）---
        if group == "shared":
            print("[流程] 发送 1 条含共享前缀的预热请求（不计入结果）...")
            warm_ids = build_prefix_tokens(0, PREFIX_LEN) + build_prefix_tokens(8888, SUFFIX_LEN)
            warm = await send_one(session, asyncio.Semaphore(1), -1, warm_ids)
            print(f"  warmup status={warm.status} prompt={warm.prompt_tokens} "
                  f"cached={warm.cached_tokens} ttft={warm.ttft_ms:.1f}ms")
            # 等待 KV 写回 RadixCache（请求结束才会 cache_finished_req）
            await asyncio.sleep(1.0)

        # --- 4. 构造 prompt 并发送 32 条测量请求 ---
        prompts = build_prompts(group)
        print(f"[流程] 发送 {N_REQUESTS} 条测量请求，最大并发 {MAX_CONCURRENCY} ...")

        sem = asyncio.Semaphore(MAX_CONCURRENCY)
        tasks = [
            asyncio.create_task(send_one(session, sem, i, prompts[i]))
            for i in range(N_REQUESTS)
        ]
        results: List[ReqResult] = await asyncio.gather(*tasks)

    # --- 5. 保存逐请求结果 ---
    per_req_path = os.path.join(out_dir, "per_request.csv")
    with open(per_req_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["req_id", "prompt_tokens", "completion_tokens", "cached_tokens",
                    "prefill_tokens", "ttft_ms", "tpot_ms", "e2e_ms", "status", "error"])
        for r in sorted(results, key=lambda x: x.req_id):
            w.writerow([r.req_id, r.prompt_tokens, r.completion_tokens, r.cached_tokens,
                        r.prefill_tokens, round(r.ttft_ms, 3), round(r.tpot_ms, 4),
                        round(r.e2e_ms, 3), r.status, r.error])

    # --- 6. 汇总 ---
    summary = summarize(group, results)
    sum_path = os.path.join(out_dir, "summary.json")
    with open(sum_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"\n[结果] 逐请求 -> {per_req_path}")
    print(f"[结果] 汇总   -> {sum_path}")
    print(json.dumps(summary, indent=2, ensure_ascii=False))

    return summary


# ============================================================


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--group", choices=["shared", "dispersed", "both"], default="both")
    args = ap.parse_args()

    groups = ["shared", "dispersed"] if args.group == "both" else [args.group]

    all_summary = {}
    for g in groups:
        all_summary[g] = asyncio.run(run_group(g))

    if len(all_summary) == 2:
        # 输出对照表
        print(f"\n{'='*64}")
        print("  对照表")
        print(f"{'='*64}")
        keys = ["success_rate", "cache_hit_rate", "avg_prefill_tokens",
                "request_throughput_rps", "output_throughput_tok_per_s",
                "ttft_p50_ms", "ttft_p95_ms", "tpot_p50_ms", "tpot_p95_ms",
                "e2e_p50_ms", "e2e_p95_ms"]
        print(f"{'指标':<32}{'shared':>14}{'dispersed':>14}")
        for k in keys:
            print(f"{k:<32}{all_summary['shared'][k]:>14}{all_summary['dispersed'][k]:>14}")

        cmp_path = os.path.abspath(os.path.join(RESULT_DIR, "comparison.json"))
        with open(cmp_path, "w", encoding="utf-8") as f:
            json.dump(all_summary, f, indent=2, ensure_ascii=False)
        print(f"\n[结果] 对照表 -> {cmp_path}")


if __name__ == "__main__":
    main()
