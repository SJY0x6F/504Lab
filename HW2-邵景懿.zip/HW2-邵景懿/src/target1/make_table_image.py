#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把两组实验结果渲染成对照表图片（用 Pillow，无需 matplotlib）。

用法：
    python make_table_image.py                   # 自动查找 comparison.json
    python make_table_image.py --results <目录>   # 指定结果目录

输出：<结果目录>/comparison_table.png
依赖：pip install pillow
"""
import argparse
import json
import os

from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))

FONT_CANDIDATES = [
    r"C:\Windows\Fonts\msyh.ttc",
    r"C:\Windows\Fonts\msyhbd.ttc",
    r"C:\Windows\Fonts\simhei.ttf",
    "/mnt/c/Windows/Fonts/msyh.ttc",
    "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
]


def find_results_dir():
    """从脚本位置向上下找含 comparison.json 的目录。"""
    cands = [
        os.path.join(HERE, "..", "results", "target1"),
        os.path.join(HERE, "..", "results"),
        os.path.join(HERE, "..", "..", "results", "target1"),
        os.path.join(HERE, "..", "..", "results"),
        HERE,
        os.getcwd(),
    ]
    for c in cands:
        c = os.path.abspath(c)
        if os.path.exists(os.path.join(c, "comparison.json")):
            return c
    raise FileNotFoundError("找不到 comparison.json，请用 --results 指定目录")


def load_font(size, bold=False):
    cands = ([FONT_CANDIDATES[1]] + FONT_CANDIDATES) if bold else FONT_CANDIDATES
    for fp in cands:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size)
            except Exception:
                continue
    return ImageFont.load_default()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=None, help="结果目录（含 comparison.json）")
    args = ap.parse_args()

    res_dir = os.path.abspath(args.results) if args.results else find_results_dir()
    print("结果目录:", res_dir)

    with open(os.path.join(res_dir, "comparison.json"), encoding="utf-8") as f:
        data = json.load(f)

    s, d = data["shared"], data["dispersed"]

    def diff(key, fmt="{:+g}"):
        return fmt.format(s[key] - d[key])

    rows = [
        ("指标", "共享前缀组 shared", "分散前缀组 dispersed", "差异"),
        ("请求数", s["n_requests"], d["n_requests"], "-"),
        ("成功率 (%)", f"{s['success_rate']:.1f}", f"{d['success_rate']:.1f}", "-"),
        ("输入长度 (token/请求)",
         s["prompt_tokens_each"][0] if s["prompt_tokens_each"] else "-",
         d["prompt_tokens_each"][0] if d["prompt_tokens_each"] else "-", "一致"),
        ("输出长度 (token/请求)",
         s["completion_tokens_each"][0] if s["completion_tokens_each"] else "-",
         d["completion_tokens_each"][0] if d["completion_tokens_each"] else "-", "一致"),
        ("缓存命中率 (%)", f"{s['cache_hit_rate']:.2f}", f"{d['cache_hit_rate']:.2f}",
         diff("cache_hit_rate")),
        ("实际 Prefill token (总)",
         f"{s['total_prefill_tokens']:,}", f"{d['total_prefill_tokens']:,}",
         f"{s['total_prefill_tokens'] - d['total_prefill_tokens']:,}"),
        ("平均 Prefill token/请求",
         f"{s['avg_prefill_tokens']:.1f}", f"{d['avg_prefill_tokens']:.1f}",
         f"{s['avg_prefill_tokens'] - d['avg_prefill_tokens']:+.1f}"),
        ("请求吞吐 (req/s)", f"{s['request_throughput_rps']:.2f}",
         f"{d['request_throughput_rps']:.2f}", diff("request_throughput_rps")),
        ("输出吞吐 (token/s)", f"{s['output_throughput_tok_per_s']:.1f}",
         f"{d['output_throughput_tok_per_s']:.1f}",
         diff("output_throughput_tok_per_s", "{:+.1f}")),
        ("TTFT p50 (ms)", f"{s['ttft_p50_ms']:.2f}", f"{d['ttft_p50_ms']:.2f}",
         diff("ttft_p50_ms", "{:+.2f}")),
        ("TTFT p95 (ms)", f"{s['ttft_p95_ms']:.2f}", f"{d['ttft_p95_ms']:.2f}",
         diff("ttft_p95_ms", "{:+.2f}")),
        ("TPOT p50 (ms)", f"{s['tpot_p50_ms']:.3f}", f"{d['tpot_p50_ms']:.3f}",
         diff("tpot_p50_ms", "{:+.3f}")),
        ("TPOT p95 (ms)", f"{s['tpot_p95_ms']:.3f}", f"{d['tpot_p95_ms']:.3f}",
         diff("tpot_p95_ms", "{:+.3f}")),
        ("端到端 p50 (ms)", f"{s['e2e_p50_ms']:.2f}", f"{d['e2e_p50_ms']:.2f}",
         diff("e2e_p50_ms", "{:+.2f}")),
        ("端到端 p95 (ms)", f"{s['e2e_p95_ms']:.2f}", f"{d['e2e_p95_ms']:.2f}",
         diff("e2e_p95_ms", "{:+.2f}")),
    ]

    FS = 19
    f_title = load_font(25, bold=True)
    f_head = load_font(FS, bold=True)
    f_body = load_font(FS)

    col_w = [330, 260, 270, 170]
    row_h = 44
    title_h = 78
    W = sum(col_w) + 40
    H = title_h + row_h * len(rows) + 40

    img = Image.new("RGB", (W, H), "#ffffff")
    dr = ImageDraw.Draw(img)

    TITLE = "SGLang 前缀缓存对照实验结果"
    tw = dr.textlength(TITLE, font=f_title)
    dr.text(((W - tw) / 2, 24), TITLE, font=f_title, fill="#1f3a5f")

    x0, y0 = 20, title_h
    dr.rectangle([x0, y0, x0 + sum(col_w), y0 + row_h], fill="#2c5f8a")

    for r, row in enumerate(rows):
        y = y0 + r * row_h
        if r > 0:
            bg = "#f2f6fa" if r % 2 == 0 else "#ffffff"
            dr.rectangle([x0, y, x0 + sum(col_w), y + row_h], fill=bg)

        x = x0
        for c, cell in enumerate(row):
            txt = str(cell)
            fnt = f_head if (r == 0 or c == 0) else f_body
            color = "#ffffff" if r == 0 else ("#1f3a5f" if c == 0 else "#202020")
            tw = dr.textlength(txt, font=fnt)
            dr.text((x + (col_w[c] - tw) / 2, y + (row_h - FS) / 2 - 3),
                    txt, font=fnt, fill=color)
            x += col_w[c]

    yy = y0
    for _ in range(len(rows) + 1):
        dr.line([x0, yy, x0 + sum(col_w), yy], fill="#c7d4e0", width=1)
        yy += row_h
    xx = x0
    for cw in col_w:
        dr.line([xx, y0, xx, y0 + row_h * len(rows)], fill="#c7d4e0", width=1)
        xx += cw
    dr.line([xx, y0, xx, y0 + row_h * len(rows)], fill="#c7d4e0", width=1)

    out = os.path.join(res_dir, "comparison_table.png")
    img.save(out)
    print("saved:", out)


if __name__ == "__main__":
    main()
