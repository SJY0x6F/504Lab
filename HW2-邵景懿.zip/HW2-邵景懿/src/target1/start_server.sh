#!/bin/bash
# ============================================================
# HW2 - 启动 SGLang 服务（Radix Cache 保持开启）
# 用法（在 WSL 中）: bash start_server.sh
# ============================================================
set -e

source ~/miniconda3/etc/profile.d/conda.sh
conda activate env-sglang

# ---------- CUDA 工具链修补（第一次挑战踩坑后固化下来的配置） ----------
SITE=$(~/miniconda3/envs/env-sglang/bin/python -c \
  "import site;print(site.getsitepackages()[0])")
export CUDA_HOME="$SITE/nvidia/cu13"

# 关键：nvcc 版本(13.2) 与 CCCL 头文件(13.0) 内部版本检查不匹配，跳过该检查
export NVCC_PREPEND_FLAGS="-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK"

# flashinfer JIT 编译并发限制，防止多核拉满导致 WSL OOM 重启
# WSL 内存有限（~12-16GB），并发过高会瞬时吃爆内存 → 被 OOM kill
export MAX_JOBS=2

# 保证 nvcc 在 PATH 最前
export PATH="$CUDA_HOME/bin:$PATH"

MODEL_DIR=~/models/Qwen3-0.6B

echo "CUDA_HOME = $CUDA_HOME"
echo "启动 SGLang 服务，端口 30000 ..."

# ---------- 启动服务 ----------
# --mem-fraction-static: 控制静态显存占用比例，为 KV cache 留余量
# --page-size 1: 默认值，最细粒度的前缀复用（便于观察命中）
# 不加 --disable-radix-cache = Radix Cache 保持开启（本任务前提）
# --log-level info: 便于观察 prefill 相关日志
exec python -m sglang.launch_server \
  --model-path "$MODEL_DIR" \
  --host 0.0.0.0 \
  --port 30000 \
  --mem-fraction-static 0.60 \
  --context-length 8192 \
  --log-level info
